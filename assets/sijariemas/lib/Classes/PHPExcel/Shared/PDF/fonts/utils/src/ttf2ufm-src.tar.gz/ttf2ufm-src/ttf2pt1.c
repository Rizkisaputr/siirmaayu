/*
 * True Type Font to Adobe Type 1 font converter 
 * By Mark Heath <mheath@netspace.net.au> 
 * Based on ttf2pfa by Andrew Weeks <ccsaw@bath.ac.uk> 
 * With help from Frank M. Siegert <fms@this.net> 
 *
 * see COPYRIGHT for full copyright notice
 *
***********************************************************************
 *
 * Steven Wittens <steven@acko.net>
 *
 * Added generation of .ufm file
 *
***********************************************************************
 *
 * Sergey Babkin <babkin@users.sourceforge.net>, <sab123@hotmail.com>
 *
 * Added post-processing of resulting outline to correct the errors
 * both introduced during conversion and present in the original font,
 * autogeneration of hints (has yet to be improved though) and BlueValues,
 * scaling to 1000x1000 matrix, option to print the result on STDOUT,
 * support of Unicode to CP1251 conversion, optimization  of the
 * resulting font code by space (that improves the speed too). Excluded
 * the glyphs that are unaccessible through the encoding table from
 * the output file. Added the built-in Type1 assembler (taken from
 * the `t1utils' package).
 *
***********************************************************************
 *
 * Thomas Henlich <thenlich@rcs.urz.tu-dresden.de>
 *
 * Added generation of .afm file (font metrics)
 * Read encoding information from encoding description file
 * Fixed bug in error message about unknown language ('-l' option)
 * Added `:' after %%!PS-AdobeFont-1.0
 * changed unused entries in ISOLatin1Encoding[] from .notdef to c127,c128...
 *
***********************************************************************
 *
 * Thomas Henlich <thenlich@rcs.urz.tu-dresden.de>
 *
 * Added generation of .afm file (font metrics)
 *
***********************************************************************
 *
 * Bug Fixes: 
************************************************************************
 *
 * Sun, 21 Jun 1998 Thomas Henlich <thenlich@Rcs1.urz.tu-dresden.de> 
 * 1. "width" should be "short int" because otherwise: 
 *     characters with negative widths (e.g. -4) become *very* wide (65532) 
 * 2. the number of /CharStrings is numglyphs and not numglyphs+1 
 *
***********************************************************************
 *
 *
 *
 * The resultant font file produced by this program still needs to be ran
 * through t1asm (from the t1utils archive) to produce a completely valid
 * font. 
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

#ifdef _GNU_SOURCE
#include <getopt.h>
#endif

#ifndef WINDOWS
#  include <unistd.h>
#  include <netinet/in.h>
#  define BITBUCKET "/dev/null"
#  include <sys/wait.h>
#else
#  define WINDOWS_FUNCTIONS /* ask to define functions - in one file only */
#  include "windows.h"
#  define BITBUCKET "NUL"
#  define snprintf _snprintf
#endif

#include "pt1.h"
#include "global.h"
#include "version.h"

/* globals */

/* table of front-ends */

extern struct frontsw ttf_sw;
extern struct frontsw bdf_sw;
#if defined(USE_FREETYPE)
  extern struct frontsw freetype_sw;
#endif

struct frontsw *frontswtab[] = {
  &bdf_sw,
#if defined(USE_FREETYPE) && defined(PREFER_FREETYPE)
  &freetype_sw,
#endif
  &ttf_sw,
#if defined(USE_FREETYPE) && !defined(PREFER_FREETYPE)
  &freetype_sw,
#endif
  NULL /* end of table */
};

struct frontsw *cursw=0; /* the active front end */
char *front_arg=""; /* optional argument */

/* options */
int      encode = 0;  /* encode the resulting file */
int      pfbflag = 0;  /* produce compressed file */
int      wantafm=0;  /* want to see .afm instead of .t1a on stdout */
int      correctvsize=0;  /* try to correct the vertical size of characters */
int      wantuid = 0;  /* user wants UniqueID entry in the font */
int      allglyphs = 0;  /* convert all glyphs, not only 256 of them */
int      warnlevel = 3;  /* the level of permitted warnings */
int      forcemap = 0; /* do mapping even on non-Unicode fonts */
/* options - maximal limits */
int      max_stemdepth = 128;  /* maximal depth of stem stack in interpreter (128 - limit from X11) */
/* options - debugging */
int      absolute = 0;  /* print out in absolute values */
int      reverse = 1;  /* reverse font to Type1 path directions */
/* options - suboptions of Outline Processing, defaults are set in table */
int      optimize;  /* enables space optimization */
int      smooth;  /* enable smoothing of outlines */
int      transform;  /* enables transformation to 1000x1000 matrix */
int      hints;  /* enables autogeneration of hints */
int      subhints;  /* enables autogeneration of substituted hints */
int      trybold;  /* try to guess whether the font is bold */
int      correctwidth;  /* try to correct the character width */
int      vectorize;  /* vectorize the bitmaps */
int      use_autotrace;  /* use the autotrace library on bitmap */
/* options - suboptions of File Generation, defaults are set in table */
int      gen_pfa;  /* generate the font file */
int      gen_afm;  /* generate the metrics file */
int      gen_ufm;  /* generate the unicode metrics file */
int      gen_dvienc;  /* generate the dvips encoding file */

/* not quite options to select a particular source encoding */
int      force_pid = -1; /* specific platform id */
int      force_eid = -1; /* specific encoding id */

/* structure to define the sub-option lists controlled by the
 * case: uppercase enables them, lowercase disables
 */
struct subo_case {
  char disbl; /* character to disable - enforced lowercase */
  char enbl;  /* character to enable - auto-set as toupper(disbl) */
  int *valp; /* pointer to the actual variable containing value */
  int  dflt; /* default value */
  char *descr; /* description */
};

int      debug = DEBUG;  /* debugging flag */

FILE    *null_file, *pfa_file, *afm_file, *ufm_file, *dvienc_file;
int      numglyphs;
struct font_metrics fontm;

/* non-globals */
static char    *strUID = 0;  /* user-supplied UniqueID */
static unsigned long numUID;  /* auto-generated UniqueID */

static int      ps_fmt_3 = 0;
static double   scale_factor, original_scale_factor;

static char  *glyph_rename[ENCTABSZ];

/* the names assigned if the original font
 * does not specify any
 */

static char    *Fmt3Encoding[256] = {
  "c0", "c1", "c2", "c3",
  "c4", "c5", "c6", "c7",
  "c8", "c9", "c10", "c11",
  "c12", "CR", "c14", "c15",
  "c16", "c17", "c18", "c19",
  "c20", "c21", "c22", "c23",
  "c24", "c25", "c26", "c27",
  "c28", "c29", "c30", "c31",
  "space", "exclam", "quotedbl", "numbersign",
  "dollar", "percent", "ampersand", "quotesingle",
  "parenleft", "parenright", "asterisk", "plus",
  "comma", "hyphen", "period", "slash",
  "zero", "one", "two", "three",
  "four", "five", "six", "seven",
  "eight", "nine", "colon", "semicolon",
  "less", "equal", "greater", "question",
  "at", "A", "B", "C",
  "D", "E", "F", "G",
  "H", "I", "J", "K",
  "L", "M", "N", "O",
  "P", "Q", "R", "S",
  "T", "U", "V", "W",
  "X", "Y", "Z", "bracketleft",
  "backslash", "bracketright", "asciicircum", "underscore",
  "grave", "a", "b", "c",
  "d", "e", "f", "g",
  "h", "i", "j", "k",
  "l", "m", "n", "o",
  "p", "q", "r", "s",
  "t", "u", "v", "w",
  "x", "y", "z", "braceleft",
  "bar", "braceright", "asciitilde", "c127",
  "c128", "c129", "quotesinglbase", "florin",
  "quotedblbase", "ellipsis", "dagger", "daggerdbl",
  "circumflex", "perthousand", "Scaron", "guilsinglleft",
  "OE", "c141", "c142", "c143",
  "c144", "quoteleft", "quoteright", "quotedblleft",
  "quotedblright", "bullet", "endash", "emdash",
  "tilde", "trademark", "scaron", "guilsinglright",
  "oe", "c157", "c158", "Ydieresis",
  "nbspace", "exclamdown", "cent", "sterling",
  "currency", "yen", "brokenbar", "section",
  "dieresis", "copyright", "ordfeminine", "guillemotleft",
  "logicalnot", "sfthyphen", "registered", "macron",
  "degree", "plusminus", "twosuperior", "threesuperior",
  "acute", "mu", "paragraph", "periodcentered",
  "cedilla", "onesuperior", "ordmasculine", "guillemotright",
  "onequarter", "onehalf", "threequarters", "questiondown",
  "Agrave", "Aacute", "Acircumflex", "Atilde",
  "Adieresis", "Aring", "AE", "Ccedilla",
  "Egrave", "Eacute", "Ecircumflex", "Edieresis",
  "Igrave", "Iacute", "Icircumflex", "Idieresis",
  "Eth", "Ntilde", "Ograve", "Oacute",
  "Ocircumflex", "Otilde", "Odieresis", "multiply",
  "Oslash", "Ugrave", "Uacute", "Ucircumflex",
  "Udieresis", "Yacute", "Thorn", "germandbls",
  "agrave", "aacute", "acircumflex", "atilde",
  "adieresis", "aring", "ae", "ccedilla",
  "egrave", "eacute", "ecircumflex", "edieresis",
  "igrave", "iacute", "icircumflex", "idieresis",
  "eth", "ntilde", "ograve", "oacute",
  "ocircumflex", "otilde", "odieresis", "divide",
  "oslash", "ugrave", "uacute", "ucircumflex",
  "udieresis", "yacute", "thorn", "ydieresis"
};

#ifdef notdef /* { */
/* This table is not used anywhere in the code
 * so it's ifdef-ed out by default but left in
 * the source code for reference purposes (and
 * possibly for future use)
 */

static char    *ISOLatin1Encoding[256] = {
  ".null", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", "CR", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  "space", "exclam", "quotedbl", "numbersign",
  "dollar", "percent", "ampersand", "quoteright",
  "parenleft", "parenright", "asterisk", "plus",
  "comma", "hyphen", "period", "slash",
  "zero", "one", "two", "three",
  "four", "five", "six", "seven",
  "eight", "nine", "colon", "semicolon",
  "less", "equal", "greater", "question",
  "at", "A", "B", "C",
  "D", "E", "F", "G",
  "H", "I", "J", "K",
  "L", "M", "N", "O",
  "P", "Q", "R", "S",
  "T", "U", "V", "W",
  "X", "Y", "Z", "bracketleft",
  "backslash", "bracketright", "asciicircum", "underscore",
  "grave", "a", "b", "c",
  "d", "e", "f", "g",
  "h", "i", "j", "k",
  "l", "m", "n", "o",
  "p", "q", "r", "s",
  "t", "u", "v", "w",
  "x", "y", "z", "braceleft",
  "bar", "braceright", "asciitilde", "c127",
  "c128", "c129", "quotesinglbase", "florin",
  "quotedblbase", "ellipsis", "dagger", "daggerdbl",
  "circumflex", "perthousand", "Scaron", "guilsinglleft",
  "OE", "c141", "c142", "c143",
  "c144", "quoteleft", "quoteright", "quotedblleft",
  "quotedblright", "bullet", "endash", "emdash",
  "tilde", "trademark", "scaron", "guilsinglright",
  "oe", "c157", "c158", "Ydieresis",
  "nbspace", "exclamdown", "cent", "sterling",
  "currency", "yen", "brokenbar", "section",
  "dieresis", "copyright", "ordfeminine", "guillemotleft",
  "logicalnot", "sfthyphen", "registered", "macron",
  "degree", "plusminus", "twosuperior", "threesuperior",
  "acute", "mu", "paragraph", "periodcentered",
  "cedilla", "onesuperior", "ordmasculine", "guillemotright",
  "onequarter", "onehalf", "threequarters", "questiondown",
  "Agrave", "Aacute", "Acircumflex", "Atilde",
  "Adieresis", "Aring", "AE", "Ccedilla",
  "Egrave", "Eacute", "Ecircumflex", "Edieresis",
  "Igrave", "Iacute", "Icircumflex", "Idieresis",
  "Eth", "Ntilde", "Ograve", "Oacute",
  "Ocircumflex", "Otilde", "Odieresis", "multiply",
  "Oslash", "Ugrave", "Uacute", "Ucircumflex",
  "Udieresis", "Yacute", "Thorn", "germandbls",
  "agrave", "aacute", "acircumflex", "atilde",
  "adieresis", "aring", "ae", "ccedilla",
  "egrave", "eacute", "ecircumflex", "edieresis",
  "igrave", "iacute", "icircumflex", "idieresis",
  "eth", "ntilde", "ograve", "oacute",
  "ocircumflex", "otilde", "odieresis", "divide",
  "oslash", "ugrave", "uacute", "ucircumflex",
  "udieresis", "yacute", "thorn", "ydieresis"
};

#endif /* } notdef */

static char    *adobe_StandardEncoding[256] = {
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  "space", "exclam", "quotedbl", "numbersign",
  "dollar", "percent", "ampersand", "quoteright",
  "parenleft", "parenright", "asterisk", "plus",
  "comma", "hyphen", "period", "slash",
  "zero", "one", "two", "three",
  "four", "five", "six", "seven",
  "eight", "nine", "colon", "semicolon",
  "less", "equal", "greater", "question",
  "at", "A", "B", "C", "D", "E", "F", "G",
  "H", "I", "J", "K", "L", "M", "N", "O",
  "P", "Q", "R", "S", "T", "U", "V", "W",
  "X", "Y", "Z", "bracketleft",
  "backslash", "bracketright", "asciicircum", "underscore",
  "quoteleft", "a", "b", "c", "d", "e", "f", "g",
  "h", "i", "j", "k", "l", "m", "n", "o",
  "p", "q", "r", "s", "t", "u", "v", "w",
  "x", "y", "z", "braceleft",
  "bar", "braceright", "asciitilde", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", ".notdef", ".notdef", ".notdef",
  ".notdef", "exclamdown", "cent", "sterling",
  "fraction", "yen", "florin", "section",
  "currency", "quotesingle", "quotedblleft", "guillemotleft",
  "guilsinglleft", "guilsinglright", "fi", "fl",
  ".notdef", "endash", "dagger", "daggerdbl",
  "periodcentered", ".notdef", "paragraph", "bullet",
  "quotesinglbase", "quotedblbase", "quotedblright", "guillemotright",
  "ellipsis", "perthousand", ".notdef", "questiondown",
  ".notdef", "grave", "acute", "circumflex",
  "tilde", "macron", "breve", "dotaccen "ellipsn Y "Arcwemi"currenc ".no", "brev.utcuteigrave"hyphen", "  "curreatdef", "grave", "acute", "circumflex",
  "tilde", "macron", "breve", "dotaccen "ellipsn Y "Arcwemi"cutfihwuef", cumflex",s("a", is"x", "y"ning varm"se h",
  l' optio4 sf", -aF,
  "tibPfihwuitilde", "c127",
  "c128", "c129", "quotesinglbase", "florin",
  "quotedblbase", "ellipsis", "dagger", "daggerdbl",
  "circumflex", "perthousand", "Scaron", "guilsinglleft",
  "OE", "c141", "c142", "c143",
  "c144", "quoteleft", "quoteright", "quotedblln  try .",
  ".144", "quoteleft", "quoteright", "quotedblln  try .",c142", "c143",o, "G",
  "H"MiM", "otil notdef", ".notdef", ".notdef",
  ".m-"Thorn", *  c",
  "d", "e", "f", "g",
  "h", "i", "j", "k",
  "l", "m", "n", "o",
  "p", "q", "r", "s",
  )Ueblln  try .",c142", "c143",o,"  "curtf", ".notdef",lex", "Ba ".notdef"bo,
  "p", urtfree"hnGstFln quote42",***to 1000x100is stusts bu", "c9i     siys/s = Diys/s
intfileallowossibl= Dworry.notdefowercase/
ssyes */flagext. A*****all,l", ".notdef   alway  avail
 *rcasefilead
stranphs a7,c128...= Di     easy.e a complete,c128...
      exp", assem<std", ".
   as/* charamizatiory.
   , "c9ie)
 *`47 015441' mizatiory.(f", , ".note ".notdeER_Fntdef")cntl.hpleteprimile mglyp43",o,alia
  isef", e the
strbl copyrign qudaggetntl.hplostat.e a", ".#dsbl; /MAXUNIALIAS 10".#dsbl; /MAXUNITABLES 3"c2", "c3", /* defauly for s/* ch,c128...e */
intse, "qior
#incdsbl; /LANG_ARG_SEP '+'"c2"ln  try . spahe me,c128...-rel[ENCTrtde/
i. A */
ingen_u:try .
      
 * the `.
  rcasefrg    
 * e   scisable

c128...-deprig
intf */
innumglywhhs (canef", exays/s oding i* chara  genp
c1".notdEeightnfrom X.numglyIfor n     cale_factbyl = 3;.g. ran empty >

# ("")    p* Thd.numglyIfor h,c128...   cisable
byl = 3;fileaph_re the
strhapprisnumgly.g. r opti   p* Thd.numgwg. rshowos "c6", to 1000x100by.
   w s/staorced con, to 1000x100bynumglyt   otd******(char staorcetwic, ".notdef", "celp p43",o, limit ft   1",tiali/
int rtde/
notdecelpotdevoi****i_1",t_t(_file,f *);def", "celp p43 limit fank M. Si-by-
   "pt1.h", "c9i ar staorcef", eas (the `.twic,:ude "std.ef", eas (the `, "c9d con, doing to 1000x100by.t   filede "std.e*****".notdecelpotde ass**i_to 1_t(_file,
  , _file,f *,e asswg. );decdsbl; /UNICONV_BYNAME_BEFORE 0decdsbl; /UNICONV_BYNAME_AFTER 1e = 0;  /* **i_,c128....notd**i_1",t_t  *1",t[MAXUNITABLES]; out i  1",tiali/
int rtde/
se, *ufm**i_to 1_t  *to 1by
  ting file
  -bl copto 1000x100"pt1.h"e, *ufm_file,
  ting file,c128...
   , *ufm_file, *dvienc_file;
int      nfm_file,alia[MAXUNIALIAS]; outalia
  p43",o,,c128...
   , *ufm asssays/s_ /* d /* poit fe ch**** char enbl /* defaulf", t */
int   ()    numglyp, "c3", nk M. Siertde/
seh"  ran o2", "c143ad
strncludsuffix = DEBUG  gen
   , *unotdef",
  ***i_ auto
  _suffix = e comprempty Encoding[25purposencludbuffSiemay<stdy forencoton, * charffix 
#incdsbl; /UNI_MAX_SUFFIX_LEN tute*unotdef",
  **i_arffix_buf[UNI_MAX_SUFFIX_LEN+1]eblln  try .Prototspahe me6", to 1000x100rtde/
s.notdef",
  ".**i_1",t_t source _ 5    ;f",
  ".**i_1",t_t source _ 5   2;f",
  ".**i_1",t_t source _ 5   4;f",
  ".**i_1",t_t source _ 5   5;f",
  ".**i_1",t_t source _ 5      ;f",
  ".**i_1",t_t source _ 5      ;f",
  ".**i_1",t_t source _p
c1";f",
  ".**i_to 1_t source _ 5      _by
  tdef",
  ".**i_1",t_t source _1",t_ = 3eblln  try .T", "cd
 *
ile;
int    iseiyscurant:s "cwe(can'tze the owercase,c128...we(just staopping6", to 1000x100rtde/
sncludcd
 udiernumgw "glilede "sGstF, "u",".nosencludthe `.e a", ,
  ".0;  /* **i_,c128...**i_,c12[] ".notd    seudo-,c128...f", ping6", ,c128...sdy 
strotdef" , *ufm.notdfm. source _ 5     },notdfm0, D */e
  -bl copn interp, *ufm "e"5    ",notdfm"worksef", moste me6", Weightnf,c128...s",notdfm{blri_otdefe_otdefr_otdenl_otdeno_otdefa_otde,t_" },notdfm'A'notd},notd{ D *EncSzalay<Taive <t***k@din "u".hu>p, *ufm ". source _ 5   2 },notdfm0, D */e
  -bl copn interp, *ufm "e"5   2",notdfm"worksef", Cof pal Europeanf,c128...s",notdfm{blhu_ot"pl_ot"cz_ot"si_ot"sk_" },notdfm'A'notd},notd{ D *EncRi�arpti �e, e <rch@WriteMe.Com>p, *ufm ". source _ 5   4d}, notdfm0, D */e
  -bl copn interp, *ufm "e"5   4",notdfm"worksef", Bal  ".,c128...s",notdfm{bllt_otdelv_" },stack ubt.notdefee_p, *ufm "'A'notd},notd{ D *EncTu */t Uy
  <uy
 @cs.itu.edu.tr>p, *ufm ". source _ 5   5d}, notdfm0, D */e
  -bl copn interp, *ufm "e"5   5",notdfm"f", Tu ki", "greafm{bltr_" },notdfm'A'notd},notd{ D *EncZvezdanfPetkov ".<z.petkov "@uoteught.org>p, *ufm ". source _ 5      , source _ 5     },notdfm0, D */e
  -bl copn interp, *ufm "e 5      ",notdfm"i****.h"

 */
st "greafm{blbg_otdebe_otdemk_otderu_otdesr_otdesu_otdeuk_" },notdfm'A'notd},notd{*ufm ". source _ 5      , source _ 5     },notdfm0, D */e
  -bl copn interp, *ufm "e 5     ",notdfm"o defet , mgly 5       /* user "greafm{b0 },notdfm'A'notd},notd{*ufm ". source _ 5      , source _ 5     },notdfm0, D */e
  -bl copn interp, *ufm "e 5       ",notdfm"o defet , mgly 5       /* user "greafm{b0 },notdfm'A'notd},notd{*ufm ". source _ 5       },notdfmsource _ 5      _by
  ,notdfm" 5      ",notdfm" With  ".notde, exp", assEncTeX "greafm{b opti},notdfm'A'notd},notd{*ufm ". source _p
c1".},notdfm0, D */e
  -bl copn interp, *ufm "ep
c1"",notdfm"o1".p
c1".p43 limit f", phs a7circu-bytre to defina  is "greafm{b opti},notdfm0 D */eeasy w y.h>
#edi bitmap apitbugget 256 of ttd},no}tdef",
  ".0;  /* **i_,c128...**i_,c12_ = 3, ".notd{ source _1",t_ = 3d}, notd0, D */e
  -bl copn interp, *ufm0, D */e
  p, *ufm0, D */eile;
int      nfm{b0 },notd0 D */esays/s  encode = 0;
  ".0;  /* **i_,c128...***i_,c12_oding edulting 0 meanst", o c12,ce lipin" a", ,
  ". ass**i_says/s='A'case days/s 143an* char enbl /* defaul, *unotdef",
  ***i_,c12_oduce compre   scale_fact
c128...-deprig
intf */
in
#endif

strn table */udi<str(n t)eblln  try .e   sdsbl; 

sad
 *  set.notdef"rposes e idea<stglilebu,
   iseh>avoi**uoteth", pret limit f*****ping0", "c1"imit s /* gener.numgAing6", 16-bit source 1000 maise

staced twe. ra*
 *
 *
", "S-t   lebu,
  .numgI",tially ping6", bu,
   n_uf", "epth****0.es ens "canlimit fie)
 *bu,
 aistry .e  d9i ar ", "epth****1.rotd
 caling eratil
int we(check)
 */
's*bu,
 afi","rcasefilei    ar 0y.g. rretutnfrailotde*
 * aw y.es (anmay<stdy ffu  "c*".no Ch/
s from X1h****manli Y "Arcwhe melong n.e a", ".#dsbl; /
/* ta_ID_BITS tu1".#dsbl; /MARK_UNI_
/* ta(source ) Sta_BITMAP(sou_ = 3_bu,
  , (source )>>(16-
/* ta_ID_BITS))".#dsbl; /IS_UNI_
/* ta(source ) IS_BITMAP(sou_ = 3_bu,
  , (source )>>(16-
/* ta_ID_BITS))".*unotdef"DEF_BITMAP(sou_ = 3_bu,
  , 1<<
/* ta_ID_BITS)tdef",
  ".**, "c5", nt source _ sec0", "c1", omprfype_sw********o source en      g,
  ". asssw*gensz, "256; outa  /* d
 *
 *
mit s e  d9otdef",
  ".voi*
source _1",t_ = 3(notdfm",
  * opt
)"..notd */
staaaaaaaa*source _ se*/
statcdsbl; /UNIBF1"i"256 nfm_fileeeeeeeeeeeebuffSi[UNIBF1"]ebl .**, "c5",,,,,,,,rce , source ,qudapos, source 2; nfm_fileeeeeeeeeee,f *,e*p;*ufm assssssssssssssalue *e, fo, ", dawp
c1";f"fm assssssssssssssotelno,qunt, 2,cn_fils; nfm_fileeeeeeeeeee n
;f"fm asssssssssssssspie, eie, oet idultdef"dflt; /eck) "cwe(h"  ran f */
in
(p
c1".
  tion */frg =.0; rchr( opt,/LANG_ARG_SEP);f"fm f(frg != 0)d{*ufm ",f *++originafm " f( sscanf(frgllipidu%d,eidu%d%,
 &pie, &eie, &n_fils) = "2 )d{*ufm "ption lists costs;les them, lowets;loet id     *ufm "ptWARNING_1 f struc(   errlliU= 3doet ridp p43",o,ructure to defi: pidu%d eidu%d\,
 pie, eie);*ufm "ption lof ste  *ufm "ptfrg +=cn_fils; nfmfm " f(*frg == ',') nfmfm "ptfrg++; nfmfm}nafm " f( *frg == 0 ||.0; in (frg) >/UNI_MAX_SUFFIX_LEN-1) *ufm "ptfrg =b opt; nfmfm
# d{*ufm "pts struc(**i_arffix_buflli-%accef *);defm "pt**i_ auto
  _suffix = **i_arffix_buf; nfmfm}nafm} def"dflt;ee"hrser ie)
 *
 * changed unused entri,) "creo", " d9otde " f ((source _ se*/
s = fopen( opt,/"r")) = " opt)d{*ufm "f struc(   errllive)  Cansiblage).en   /
s '%s' ve) \,
 popt);defm "exit(1);defm}def"dfdawp
c1"originafm f(frg== opt)defm "elue *e = fo, "ste  *ufm
#  dfm "elue *e = fo, "steltdef"dfotelnoultiudapos=ginafmwh******g
   (buffSi,/UNIBF1", source _ se*/
s) !=  opt)d{*ufm "_file
  "cUNIBF1"]ebl*ufm "otelno++; nnafm " f(sscanf(buffSi,/ep
c1" %acce
  t==1)d{*ufm "ptdawp
c1"ori1; nfmfm " f(frg == 0)d{*ufm "pt "f struc(   errllive)  n   /
s '%s' reo"ir s p
c1".
  \,
 popt);defm "pt "f struc(   errllif", exays/s:\,);defm "pt "f struc(   errlli  45 0133 -L %a%c[piduN,eiduN,]%s ...\,
 defm "pt "   opt,/LANG_ARG_SEPce
  t;defm "pt "f struc(   errlliencoding ip
c1".'%s'\,
 
  t;defm "pt "exit(1);defmfmfm}nafm " " f( !0; cmp(frgll
  ti)d{*ufm "pt "elue *e = fo, "ste   defm "pt "udaposoriginafm "fm} 
# d{*ufm "pt "elue *e = 0;defm "pt " f(fo, ") D */e assemhrser furhs a7, *ufm """""""brsek;defmfmfm}nafm " "flaginue; nfmfm}nanafm " f(sscanf(buffSi,/eid %d %d
 &pie, &eiet==2)d{*ufm "pt f( !oet id en_aUnic "c6",  = 3dUnicsibloet ridpn7, *ufm """&& (elue *e ||.!dawp
c1"ti)d{ defm "pt "ion lists costs;les them, lowets;defm "pt "ion lof ste  *ufm "pt}nafm " "flaginue; nfmfm}nanafm " f( !elue *e )nafm " "flaginue;ase dkip = DEBUGn
ip
c1".otdef"fm " f( sscanf(buffSi,/eat %".m-&udapos) = "1 )d{*ufm "pt f(udaposo>"255)d{*ufm "pt "f struc(   errllive)  n   /
s '%s' thing%d:poit feet "255\,
 popt,"otelnot;defm "pt "exit(1);defmfmfm}nafm " " f(ISDBG(EXTMAP)) f struc(   errlli== "at 0x%x\,
 udapos);nafm " "flaginue; nfmfm}nanafm "race libBUG   of  p43Roman Czyborra'g */
s7, *ufm " f ( sscanf (buffSi,/" =%x U+%4x.m-&uce ,q&source ) = "2nafm "race libBUG   of  p43Linuxplostat"_filn   /
s , *ufm "||.0scanf (buffSi,/" <%*s /x%x <U%4x>.m-&uce ,q&source ) = "2 )d{*ufm "pt f (oit f<g0", "c1")d{*ufm "pt " f(uit f>=ssw*gensz)ssw*gensz=uit +1;defm "pt "source _ secrce ] = **irce ;defm "pt "56] = {
  "crce ] =  opt; nfmfmfm}nafm "}nafm "race libBUG   of  h****the `.{
  terp, *ufm "
# d f (0scanf (buffSi,/" !%x U+%4x %128s.m-&uce ,*ufm """&source ,q
  ti= "3)d{*ufm "pt f (oit f<g0", "c1")d{*ufm "pt " f(uit f>=ssw*gensz)ssw*gensz=uit +1;defm "pt "source _ secrce ] = **irce ;defm "pt "56] = {
  "crce ] = 0; dup(
  t;defm "pt}nafm "}nafm "race libBUGuotetppereo",.not   of  , *ufm "
# d f( (n=sscanf(buffSi,/e %"%,
 &source ,q&unt)) = "1 )d{*ufm "pt stebuffSi;defm "ptdod{*ufm "pt " f(udaposo>"255)d{*ufm "pt " "f struc(   errllive)  n   /
s '%s' thing%d:poit feet "255ef", source e0x%x\,
 *ufm "pt " "  popt,"otelno, source t;defm "pt " "exit(1);defmfmfmfm}nafm " " " f(ISDBG(EXTMAP)) f struc(   errlli== "0x%d -> 0x%x\,
 udapos, source t;defm "pt "source _ secrdapos++] = **irce ;defm "pt "p +=cunt;defm "pt " f( sscanf(p,/e %[,-]%,
 &n
,&unt) = "1 )d{*ufm "pt " " f(ISDBG(EXTMAP)) f struc(   errlli== "n
: '%c'\,
 
t;defm "pt " "p +=cunt;defm "pt " " f( n
i== '-'i)d{ timi****7, *ufm """"""" " f ( sscanf(p,/e %"%,
 &source 2,q&unt) != 1 )d{*ufm "pt " " " "f struc(   errllive)  n   /
s '%s' thing%d:pmihe
str */
ini****\,
 popt,"otelnot;defm "pt "pt " "exit(1);defmfmfmfmfmfm}nafm " " " " "p +=cunt;defm "pt " " " f(ISDBG(EXTMAP)) f struc(   errlli== "i****70x%x = D0x%x\,
 source ,qsource 2);defmfmfmfmfmfmf",(source ++; source e<= source 2; source ++)d{*ufm "pt " " " " f(udaposo>"255)d{*ufm "pt " " " " "f struc(   errllive)  n   /
s '%s' thing%d:poit feet "255eie)source ei****7...-0x%x\,
 *ufm "pt " "   " " "popt,"otelno, source 2);defmfmfmfmfmfm " "exit(1);defmfmfmfmfmfmfm}nafm " " " " " " f(ISDBG(EXTMAP)) f struc(   errlli== "0x%x -> 0x%x\,
 udapos, source t;defm "pt """""""source _ secrdapos++] = **irce ;defm "pt "fmfm}nafm " " " "}defmfmfmfm}nafm " "}mwh***** sscanf(p,/e %"%,
 &source ,q&unt) = "1 ); nfmfm}nanafm}nanafmfclo# d(source _ se*/
s); nnafm f( !fo, "s)d{*ufm "f struc(   errllive)  n   /
s '%s' Unicsiip
c1".'%s'\,
 popt,"f *);defm "exit(1);defm}def"dfif(source _ se['A']i== 'A') nfmfm**i_says/s = 'A';ase deemude <stduotettnote h****otdef7, *ufm
#  dfm "**i_says/s = m stack n'tzmakecanliassumafm=0;  /* }blln  try .EncZvezdanfPetkov ".<z.petkov "@uoteught.org>pe a", ,
  ".voi*
source _ 5      (notdfm",
  *f *
)"..notd assi;defm,
  ".**, "c5", nt  5      _source _ se[", ".notd  0x0402,q0x0403,q0x201a,q0x0453,q0x201e,q0x2026,q0x2020,q0x2021, "rac807, *ufm "0x20ac,q0x2030,q0x0409,q0x2039,q0x040a,q0x040c,q0x040b,q0x040f, "rac887, *ufm "0x0452,q0x2018,q0x2019,q0x201c,q0x201d,q0x2022,q0x2013,q0x2014, "rac907, *ufm "0x02dc,q0x2122,q0x0459,q0x203a,q0x045a,q0x045c,q0x045b,q0x045f, "rac987, *ufm "0x00a0,q0x040e,q0x045e,q0x0408,q0x00a4,q0x0490,q0x00a6,q0x00a7, "racA07, *ufm "0x0401,q0x00a9,q0x0404,q0x00ab,q0x00ac,q0x00ad,q0x00ae,q0x0407, "racA87, *ufm "0x00b0,q0x00b1,q0x0406,q0x0456,q0x0491,q0x00b5,q0x00b6,q0x00b7, "racB07, *ufm "0x0451,q0x2116,q0x0454,q0x00bb,q0x0458,q0x0405,q0x0455,q0x0457, "racB87, *ufm}; nnafmf",(iultii<=0x7Ftii++) dfm "**irce _ se[i", "i; nnafmf",(iulx8ltii<=0xBFtii++) dfm "**irce _ se[i", " 5      _source _ se[i-lx8l]; nnafmf",(iulxCltii<=0xFFtii++) dfm "**irce _ se[i", "i+0x35ltdef"}def",
  ".voi*
source _ 5    (notdfm",
  *f *
)"..notd assi;defm,
  ".**, "c5", nt  5    _source _ se[", ".notd  0x20ac,qqqqq-1,q0x201a,q0x0192,q0x201e,q0x2026,q0x2020,q0x2021, "rac807, *ufm "0x02c6,q0x2030,q0x0160,q0x2039,q0x0152,q0x008d,q0x017d,q0x008f, "rac887, *ufm "0x0090,q0x2018,q0x2019,q0x201c,q0x201d,q0x2022,q0x2013,q0x2014, "rac907, *ufm "0x02dc,q0x2122,q0x0161,q0x203a,q0x0153,q0x009d,q0x017e,q0x0178, "rac987, *ufm}; nnafmf",(iultii<=0x7Ftii++) dfm "**irce _ se[i", "i; nnafmf",(iulx8ltii<=0x9Ftii++) dfm "**irce _ se[i", " 5    _source _ se[i-lx8l]; nnafmf",(iulxAltii<=0xFFtii++) dfm "**irce _ se[i", "i;f"}def",
  ".voi*
source _ 5      (notdfm",
  *f *
)"..notd assi;defm,
  ".**, "c5", nt  5      _source _ se[", ".notd  qq-1,q0x00a1,q0x00a2,q0x00a3,q0x2215,q0x00a5,q0x0192,q0x00a7, "racA07, *ufm "0x00a4,q0x0027,q0x201c,q0x00ab,q0x2039,q0x203a,q0xfb01,q0xfb02, "racA87, *ufm "qq-1,q0x2013,q0x2020,q0x2021, 0x2219,d  qq-1,q0x00b6,q0x2022,q"racB07, *ufm "0x201a,q0x201e,q0x201d,q0x00bb,q0x2026,q0x2030,q  qq-1,q0x00bf, "racB87, *ufm  qq-1,q0x0060,q0x00b4,q0x02c6,q0x02dc,q0x02c9,q0x02d8,q0x02d9, "racC07, *ufm "0x00a8,q  qq-1,q0x02da,q0x00b8,q  qq-1,q0x02dd,q0x02db,q0x02c7, "racC87, *ufm "0x2014,q  qq-1,q  qq-1,q  qq-1,q  qq-1,q  qq-1,q  qq-1,q  qq-1,q racD07, *ufm  qq-1,q  qq-1,q  qq-1,q  qq-1,q  qq-1,q  qq-1,q  qq-1,q  qq-1,q racD87, *ufm  qq-1,q0x00c6,q  qq-1,q0x00aa,q  qq-1,q  qq-1,q  qq-1,q  qq-1,q racE07, *ufm "0x0141,q0x00d8,q0x0152,q0x00ba,q  qq-1,q  qq-1,q  qq-1,q  qq-1,q racE87, *ufm  qq-1,q0x00e6,q  qq-1,q  qq-1,q  qq-1,q0x0131,q  qq-1,q  qq-1,q racF07, *ufm "0x0142,q0x00f8,q0x0153,q0x00df,q  qq-1,q  qq-1,q  qq-1,q  qq-1,q racF87, *ufm}; nnafmf",(iultii<=0x7Ftii++) dfm "**irce _ se[i", "i; nnafm**irce _ se[0x27", "0x2019;nafm**irce _ se[0x60]lowercdef"dflt;lx8l = D0x9Ff   a hol".otdef"fmf",(iulxAltii<=0xFFtii++) dfm "**irce _ se[i", " 5      _source _ se[i-lxAl]; n}blln  try .Noappingp43",o, With t font fe use)
 * "Ba ".notd s".notde  set,tic EBUG  genc", "orseh"  notd dif", ".t ideas.notdefoweir
mit s. B numglnotd p43",   wece libran   bl copyrign qthe `, "c9
  "c/* user wan limit fant s. I43",or.e lnotd siithe `.
  s ( if the !=0)gw "gping", "notd = DEBUGant -bl copschemt.e a", ".,
  ". as
source _ 5      _by
  (notdfm",
  *
  ,notdfm _file,f *,notdfm  asswg. lno)"..notd assi;def"dflt;
  "c4lway  nlic
#eced,.noteet "mit s otde " f(ture u== UNICONV_BYNAME_AFTER) dfm "retutnfercdef"dff",(iu32tii<256; i++)d{*ufm " f(!0; cmp(
  , tdef", ".notdef", ".noti]))nafm " "retutnfi;defm}de "retutnfercdef"}def",
  ".voi*
source _ 5   2(notdfm",
  *f *
)"..notd assi;defm,
  ".**, "c5", nt  5   2_source _ se[", ".notd  0x00a0,q0x0104,q0x02d8,q0x0141,q0x00a4,q0x013d,q0x015a,q0x00a7, "racA07, *ufm "0x00a8,q0x0160,q0x015e,q0x0164,q0x0179,q0x00ad,q0x017d,q0x017b, "racA87, *ufm "0x00b0,q0x0105,q0x02db,q0x0142,q0x00b4,q0x013e,q0x015b,q0x02c7, "racB07, *ufm "0x00b8,q0x0161,q0x015f,q0x0165,q0x017a,q0x02dd,q0x017e,q0x017c, "racB87, *ufm  0x0154,q0x00c1,q0x00c2,q0x0102,q0x00c4,q0x0139,q0x0106,q0x00c7, "racC07, *ufm "0x010c,q0x00c9,q0x0118,q0x00cb,q0x011a,q0x00cd,q0x00ce,q0x010e,q"racC87, *ufm "0x0110,q0x0143,q0x0147,q0x00d3,q0x00d4,q0x0150,q0x00d6,q0x00d7,q racD07, *ufm  0x0158,q0x016e,q0x00da,q0x0170,q0x00dc,q0x00dd,q0x0162,q0x00df,q racD87, *ufm  0x0155,q0x00e1,q0x00e2,q0x0103,q0x00e4,q0x013a,q0x0107,q0x00e7,q racE07, *ufm "0x010d,q0x00e9,q0x0119,q0x00eb,q0x011b,q0x00ed,q0x00ee,q0x010f,q racE87, *ufm  0x0111,q0x0144,q0x0148,q0x00f3,q0x00f4,q0x0151,q0x00f6,q0x00f7,q racF07, *ufm "0x0159,q0x016f,q0x00fa,q0x0171,q0x00fc,q0x00fd,q0x0163,q0x02d9, "racF87, *ufm}; nnafmf",(iultii<=0x7Etii++) dfm "**irce _ se[i", "i; nnafmrac7F-9Ff' packe  d9otdef"fmf",(iulxAltii<=0xFFtii++) dfm "**irce _ se[i", " 5   2_source _ se[i-lxAl]; n}blln,
  ".voi*
source _ 5   4(notdfm",
  *f *
)"..notd assi;defm,
  ".**, "c5", nt  5   4_source _ se[", ".notd  0x0080,q0x0081,q0x201a,q0x0192,q  qq-1,q0x2026,q0x2020,q0x2021, "rac807, *ufm "0x02c6,q0x2030,q  qq-1,q0x2039,q0x0152,q0x008d,q0x008e,q0x008f, "rac887, *ufm "0x201e,q0x201c,q0x2019,q  qq-1,q0x201d,q0x2022,q0x2013,q0x2014, "rac907, *ufm "0x02dc,q0x2122,q  qq-1,q0x203a,q0x0153,q0x009d,q0x009e,q0x0178, "rac987, *ufm  0x00a0,q0x0104,q0x0138,q0x0156,q0x00a4,q0x0128,q0x013b,q0x00a7, "racA07, *ufm "0x00a8,q0x0160,q0x0112,q0x0122,q0x0166,q0x00ad,q0x017d,q0x00af, "racA87, *ufm "0x00b0,q0x0105,q0x02db,q0x0157,q0x00b4,q0x0129,q0x013c,q0x02c7, "racB07, *ufm "0x00b8,q0x0161,q0x0113,q0x0123,q0x0167,q0x014a,q0x017e,q0x014b, "racB87, *ufm  0x0100,q0x00c1,q0x00c2,q0x00c3,q0x00c4,q0x00c5,q0x00c6,q0x012e, "racC07, *ufm "0x010c,q0x00c9,q0x0118,q0x00cb,q0x0116,q0x00cd,q0x00ce,q0x012a,q"racC87, *ufm "0x0110,q0x0145,q0x014c,q0x0136,q0x00d4,q0x00d5,q0x00d6,q0x00d7,q racD07, *ufm  0x00d8,q0x0172,q0x00da,q0x00db,q0x00dc,q0x0168,q0x016a,q0x00df,q racD87, *ufm  0x0101,q0x00e1,q0x00e2,q0x00e3,q0x00e4,q0x00e5,q0x00e6,q0x012f,q racE07, *ufm "0x010d,q0x00e9,q0x0119,q0x00eb,q0x0117,q0x00ed,q0x00ee,q0x012b,q racE87, *ufm  0x0111,q0x0146,q0x014d,q0x0137,q0x00f4,q0x00f5,q0x00f6,q0x00f7,q racF07, *ufm "0x00f8,q0x0173,q0x00fa,q0x00fb,q0x00fc,q0x0169,q0x016b,q0x02d9, "racF87, *ufm}; nnafmf",(iultii<=0x7Ftii++) dfm "**irce _ se[i", "i; nnafmf",(iulx8ltii<=0xFFtii++) dfm "**irce _ se[i", " 5   4_source _ se[i-lx8l]; nnasw=00omprfyr doc/
in
int def",
  l.h"
#in e */"0x201e:"retutnf0x9lting fil* gewo def", f' paa hint l.h"
#in e */"0x201c:"retutnf0x91ting fil* gewo def", f' paa hint l.h"
#in e */"0x00A0:"retutnf0xAlting  NO-BREAK SPACE
#in e */"0x0104:"retutnf0xA1ting  LATIN CAPITAL LETTER A WITH OGONEK
#in e */"0x0138:"retutnf0xA2ting  LATIN SMALL LETTER KRA
#in e */"0x0156:"retutnf0xA3ting  LATIN CAPITAL LETTER R WITH CEDILLA
#in e */"0x00A4:"retutnf0xA4ting  CURRENCY SIGN
#in e */"0x0128:"retutnf0xA5ting  LATIN CAPITAL LETTER I WITH TILDE
#in e */"0x013B:"retutnf0xA6ting  LATIN CAPITAL LETTER L WITH CEDILLA
#in e */"0x00A7:"retutnf0xA7ting  SEntf
 SIGN
#in e */"0x00A8:"retutnf0xA8ting  DIAERESIS
#in e */"0x0160:"retutnf0xA9ting  LATIN CAPITAL LETTER S WITH CARON
#in e */"0x0112:"retutnf0xAAting  LATIN CAPITAL LETTER E WITH MACRON
#in e */"0x0122:"retutnf0xABting  LATIN CAPITAL LETTER G WITH CEDILLA
#in e */"0x0166:"retutnf0xACting  LATIN CAPITAL LETTER T WITH STROKE
#in e */"0x00AD:"retutnf0xADting  SOFT HYPHEN
#in e */"0x017D:"retutnf0xAEting  LATIN CAPITAL LETTER Z WITH CARON
#in e */"0x00AF:"retutnf0xAFting  MACRON
#in e */"0x00B0:"retutnf0xBlting  DEGREE SIGN
#in e */"0x0105:"retutnf0xB1ting  LATIN SMALL LETTER A WITH OGONEK
#in e */"0x02DB:"retutnf0xB2ting  OGONEK
#in e */"0x0157:"retutnf0xB3ting  LATIN SMALL LETTER R WITH CEDILLA
#in e */"0x00B4:"retutnf0xB4ting  ACUTE ACCENT
#in e */"0x0129:"retutnf0xB5ting  LATIN SMALL LETTER I WITH TILDE
#in e */"0x013C:"retutnf0xB6ting  LATIN SMALL LETTER L WITH CEDILLA
#in e */"0x02C7:"retutnf0xB7ting  CARON
#in e */"0x00B8:"retutnf0xB8ting  CEDILLA
#in e */"0x0161:"retutnf0xB9ting  LATIN SMALL LETTER S WITH CARON
#in e */"0x0113:"retutnf0xBAting  LATIN SMALL LETTER E WITH MACRON
#in e */"0x0123:"retutnf0xBBting  LATIN SMALL LETTER G WITH CEDILLA
#in e */"0x0167:"retutnf0xBCting  LATIN SMALL LETTER T WITH STROKE
#in e */"0x014A:"retutnf0xBDting  LATIN CAPITAL LETTER ENG
#in e */"0x017E:"retutnf0xBEting  LATIN SMALL LETTER Z WITH CARON
#in e */"0x014B:"retutnf0xBFting  LATIN SMALL LETTER ENG
#in e */"0x0100:"retutnf0xC0ting  LATIN CAPITAL LETTER A WITH MACRON
#in e */"0x00C1:"retutnf0xC1ting  LATIN CAPITAL LETTER A WITH ACUTE 
#in e */"0x00C2:"retutnf0xC2ting  LATIN CAPITAL LETTER A WITH CIRCUMFLEX 
#in e */"0x00C3:"retutnf0xC3ting  LATIN CAPITAL LETTER A WITH TILDE
#in e */"0x00C4:"retutnf0xC4ting  LATIN CAPITAL LETTER A WITH DIAERESIS
#in e */"0x00C5:"retutnf0xC5ting  LATIN CAPITAL LETTER A WITH RINGABOVE
#in e */"0x00C6:"retutnf0xC6ting  LATIN CAPITAL LIGATURE AE
#in e */"0x012E:"retutnf0xC7ting  LATIN CAPITAL LETTER I WITH OGONEK
#in e */"0x010C:"retutnf0xC8ting  LATIN CAPITAL LETTER C WITH CARON
#in e */"0x00C9:"retutnf0xC9ting  LATIN CAPITAL LETTER E WITH ACUTE 
#in e */"0x0118:"retutnf0xCAting  LATIN CAPITAL LETTER E WITH OGONEK
#in e */"0x00CB:"retutnf0xCBting  LATIN CAPITAL LETTER E WITH DIAERESIS
#in e */"0x0116:"retutnf0xCCting  LATIN CAPITAL LETTER E WITH DOTABOVE
#in e */"0x00CD:"retutnf0xCDting  LATIN CAPITAL LETTER I WITH ACUTE 
#in e */"0x00CE:"retutnf0xCEting  LATIN CAPITAL LETTER I WITH CIRCUMFLEX 
#in e */"0x012A:"retutnf0xCFting  LATIN CAPITAL LETTER I WITH MACRON
#in e */"0x0110:"retutnf0xD0ting  LATIN CAPITAL LETTER D WITH STROKE
#in e */"0x0145:"retutnf0xD1ting  LATIN CAPITAL LETTER N WITH CEDILLA
#in e */"0x014C:"retutnf0xD2ting  LATIN CAPITAL LETTER O WITH MACRON
#in e */"0x0136:"retutnf0xD3ting  LATIN CAPITAL LETTER K WITH CEDILLA
#in e */"0x00D4:"retutnf0xD4ting  LATIN CAPITAL LETTER O WITH CIRCUMFLEX 
#in e */"0x00D5:"retutnf0xD5ting  LATIN CAPITAL LETTER O WITH TILDE
#in e */"0x00D6:"retutnf0xD6ting  LATIN CAPITAL LETTER O WITH DIAERESIS
#in e */"0x00D7:"retutnf0xD7ting  MULTIPLICAtf
 SIGN
#in e */"0x00D8:"retutnf0xD8ting  LATIN CAPITAL LETTER O WITH STROKE
#in e */"0x0172:"retutnf0xD9ting  LATIN CAPITAL LETTER U WITH OGONEK
#in e */"0x00DA:"retutnf0xDAting  LATIN CAPITAL LETTER U WITH ACUTE 
#in e */"0x00DB:"retutnf0xDBting  LATIN CAPITAL LETTER U WITH CIRCUMFLEX 
#in e */"0x00DC:"retutnf0xDCting  LATIN CAPITAL LETTER U WITH DIAERESIS
#in e */"0x0168:"retutnf0xDDting  LATIN CAPITAL LETTER U WITH TILDE
#in e */"0x016A:"retutnf0xDEting  LATIN CAPITAL LETTER U WITH MACRON
#in e */"0x00DF:"retutnf0xDFting  LATIN SMALL LETTER SHARP S
#in e */"0x0101:"retutnf0xE0ting  LATIN SMALL LETTER A WITH MACRON
#in e */"0x00E1:"retutnf0xE1ting  LATIN SMALL LETTER A WITH ACUTE 
#in e */"0x00E2:"retutnf0xE2ting  LATIN SMALL LETTER A WITH CIRCUMFLEX 
#in e */"0x00E3:"retutnf0xE3ting  LATIN SMALL LETTER A WITH TILDE
#in e */"0x00E4:"retutnf0xE4ting  LATIN SMALL LETTER A WITH DIAERESIS
#in e */"0x00E5:"retutnf0xE5ting  LATIN SMALL LETTER A WITH RINGABOVE
#in e */"0x00E6:"retutnf0xE6ting  LATIN SMALL LIGATURE AE
#in e */"0x012F:"retutnf0xE7ting  LATIN SMALL LETTER I WITH OGONEK
#in e */"0x010D:"retutnf0xE8ting  LATIN SMALL LETTER C WITH CARON
#in e */"0x00E9:"retutnf0xE9ting  LATIN SMALL LETTER E WITH ACUTE 
#in e */"0x0119:"retutnf0xEAting  LATIN SMALL LETTER E WITH OGONEK
#in e */"0x00EB:"retutnf0xEBting  LATIN SMALL LETTER E WITH DIAERESIS
#in e */"0x0117:"retutnf0xECting  LATIN SMALL LETTER E WITH DOTABOVE
#in e */"0x00ED:"retutnf0xEDting  LATIN SMALL LETTER I WITH ACUTE 
#in e */"0x00EE:"retutnf0xEEting  LATIN SMALL LETTER I WITH CIRCUMFLEX 
#in e */"0x012B:"retutnf0xEFting  LATIN SMALL LETTER I WITH MACRON
#in e */"0x0111:"retutnf0xF0ting  LATIN SMALL LETTER D WITH STROKE
#in e */"0x0146:"retutnf0xF1ting  LATIN SMALL LETTER N WITH CEDILLA
#in e */"0x014D:"retutnf0xF2ting  LATIN SMALL LETTER O WITH MACRON
#in e */"0x0137:"retutnf0xF3ting  LATIN SMALL LETTER K WITH CEDILLA
#in e */"0x00F4:"retutnf0xF4ting  LATIN SMALL LETTER O WITH CIRCUMFLEX 
#in e */"0x00F5:"retutnf0xF5ting  LATIN SMALL LETTER O WITH TILDE
#in e */"0x00F6:"retutnf0xF6ting  LATIN SMALL LETTER O WITH DIAERESIS
#in e */"0x00F7:"retutnf0xF7ting  DIVISf
 SIGN
#in e */"0x00F8:"retutnf0xF8ting  LATIN SMALL LETTER O WITH STROKE
#in e */"0x0173:"retutnf0xF9ting  LATIN SMALL LETTER U WITH OGONEK
#in e */"0x00FA:"retutnf0xFAting  LATIN SMALL LETTER U WITH ACUTE 
#in e */"0x00FB:"retutnf0xFBting  LATIN SMALL LETTER U WITH CIRCUMFLEX 
#in e */"0x00FC:"retutnf0xFCting  LATIN SMALL LETTER U WITH DIAERESIS
#in e */"0x0169:"retutnf0xFDting  LATIN SMALL LETTER U WITH TILDE
#in e */"0x016B:"retutnf0xFEting  LATIN SMALL LETTER U WITH MACRON
#in e */"0x02D9:"retutnf0xFFting  DOTABOVE
#in ".not n}blln,
  ".voi*
source _ 5   5(notdfm",
  *f *
)"..notd assi;defm,
  ".**, "c5", nt  5   5_source _ se1[", ".notd  0x0080,q0x0081,q0x201a,q0x0192,q0x201e,q0x2026,q0x2020,q0x2021, "rac807, *ufm "0x02c6,q0x2030,q0x0160,q0x2039,q0x0152,q0x008d,q0x008e,q0x008f, "rac887, *ufm "0x0090,q0x2018,q0x2019,q0x201c,q0x201d,q0x2022,q0x2013,q0x2014, "rac907, *ufm "0x02dc,q0x2122,q0x0161,q0x203a,q0x0153,q0x009d,q0x009e,q0x0178, "rac987, *ufm};defm,
  ".**, "c5", nt  5   5_source _ se2[", ".notd  0x011e,q0x00d1,q0x00d2,q0x00d3,q0x00d4,q0x00d5,q0x00d6,q0x00d7,q racD07, *ufm  0x00d8,q0x00d9,q0x00da,q0x00db,q0x00dc,q0x0130,q0x015e,q0x00df,q racD87, *ufm  0x00e0,q0x00e1,q0x00e2,q0x00e3,q0x00e4,q0x00e5,q0x00e6,q0x00e7,q racE07mizati7, *ufm  0x00e8,q0x00e9,q0x00ea,q0x00eb,q0x00ec,q0x00ed,q0x00ee,q0x00ef,q racE87mizati7, *ufm  0x011f,q0x00f1,q0x00f2,q0x00f3,q0x00f4,q0x00f5,q0x00f6,q0x00f7,q racF07, *ufm "0x00f8,q0x00f9,q0x00fa,q0x00fb,q0x00fc,q0x0131,q0x015f,q0x00ff, "racF87, *ufm}; nnafmf",(iultii<=0x7Ftii++) dfm "**irce _ se[i", "i; nnafmf",(iulx8ltii<=0x9Ftii++) dfm "**irce _ se[i", " 5   5_source _ se1[i-lx8l]; nnafmf",(iulxAltii<=0xCFtii++) dfm "**irce _ se[i", "i; nnafmf",(iulxDltii<=0xFFtii++) dfm "**irce _ se[i", " 5   5_source _ se2[i-lxDl]; n}blln   a w y.h>oding io1".256- /* defaulp
c1".nex", "Ba ".ntl.hp", phs a7circu-bytre to defie a", ".,
  ".voi*
source _p
c1"(notdfm",
  *f *
)"..notd,
  ".**, "c5",p
c1";f"fm assn_fils; nfm nt  1,qc2,qi; nnafmif(sou_,c12_oding ed == 0)notdfmretutn stack n'tzpar  "ipat use)aph_re the
strotdef"fmp
c1"origi"ion lists coes them, lowercdef"dfc1 = 0scanf(frgllipidu%d,eidu%d%,
 &ion lists
 &ion lieie, &n_fils)inafm f(c1 == 2)d{*ufm "frg +=cn_fils; nfmfm f(*frg == ',') nfmfm "frg++; nfm}nafm f(frg[0]i== '0'"&& (frg[1]=='x'"||.frg[1]=='X'ti)d{*ufm "frg +=c2; nfmfmc2 = 0scanf(frglli%x.m-&p
c1"t; nfm} 
# d{*ufm "c2 = 0scanf(frglli%d.m-&p
c1"t; nfm} nnafm f( (c1!=2"&& c1!=0)"||.(c1==0"&& c2==0)")d{*ufm "f struc(   errllive)  o2", "c-lmp
c1"oexp", sio1".p43",o,follow
str   of s:\,);defm "f struc(   errlli  -lmp
c1"+0xNN -oding ihexadecim* d
 *
 *
p
c1".p43 limit \,);defm "f struc(   errlli  -lmp
c1"+NN -oding idecim* d
 *
 *
p
c1".p43 limit \,);defm "f struc(   errlli  -lmp
c1"+piduN,eiduN -oding ip
c1".0fe chisable
 to defi\,);defm "f struc(   errlli  -lmp
c1"+piduN,eiduN,0xNN -oding ihex
p
c1".p43TTF*
 * chanh****",   PID/EID\,);defm "f struc(   errlli  -lmp
c1"+piduN,eiduN,NN -oding idecim* dp
c1".p43TTF*
 * chanh****",   PID/EID\,);defm "exit(1);defm}def"dfif(c2!=0)"{*ufm " f(0; in (frg) >/t   oc(**i_arffix_buf)-2)d{*ufm "ptf struc(   errllive)  p
c1".
 *
 iseh> h,crg \,);defm "}nanafm "s struc(**i_arffix_buflli-%accef *);defm "**i_ auto
  _suffix = **i_arffix_buf; nfm} 
# d{*ufm "**i_ auto
  _suffix = "";defm}def"dfp
c1".<<= 8;nafmf",(iultii<=0xFFtii++) dfm "**irce _ se[i", "p
c1".|"i;f"}def"/hplook up3",o,8-bit a ".nbyl "Ba ".notdef" as
source _rev_lookup(notdfm" nt souval
)"..notd assres; nnafm f( !/IS_UNI_
/* ta(souval) ) dfm "retutnfercdef"dff", (r s rigi"r s <ssw*genszi"r s++) dfm " f (**irce _ se[r s]i== souval)*ufm "ptretutnfres; n "retutnfercde}def"/hp", "g6", bu,
   f", quick lookup a", ".,
  ".voi*
source _pre, "e_bu,
  (notdvoi*
)"..notd assi;def"dfmemset(sou_ = 3_bu,
  , 0,qt   oc sou_ = 3_bu,
  );nafmf",(iultii<sw*genszi"i++)d{*ufm " f(**irce _ se[i",!= (**, "c5")fer)*ufm "ptMARK_UNI_
/* ta(source _ se[i");defm}de}blln  try .Wg. rwtepriasssrrorsenotdefbad;
  "cw  w nt.h>
#iassfil* g
  "c/*try .h****decent-look
str   oe a", ".,
  ".,
  *

  to
#ias(notd**, "c5",,
  *s
)"..notd,
  ".,
  res[50]; nfm nt  ,"i; nnafmf",(iul; ( c = .h )!=0"&& i<t   oc(res)-8; s++)d{*ufm " f(c <s' '"||.c >/126)d{*ufm "ptd struc(r s+illi\\x%02", "ct;defm "pti+=4;defm "} 
# d{*ufm "ptres[i++] = c;defm "}nafm}nafm f(*s != 0)d{*ufm "res[i++] = '.';*ufm "res[i++] = '.';*ufm "res[i++] = '.';*ufm}de "res[i++] = 0; n "retutnfres; n}blln  try .Sstat"6", valu, f'ccor******o ",o,rstat_fatiore a", ".k ub *rcfrstat(notdfm" k ub * val
)"..notdretutnfrstat_fatiory .val; n}blln as
irstat(notdfm"  nt val
)"..notdretutnf(n t) (val >/0 ?frstat_fatiory .val + 0.5notdfm"     :frstat_fatiory .val - 0.5); n}blln  try .T libraion l fixepth*d****
m/* defaus.notdef",
  ".voi*
al "ch*d**s(voi*)"..notd assssssssssssssi;notd assssssssssssssn = 0cefvgllmax = 0cemin = 3000,qsum = 0cexcdef"dff", (i rigi"i <s
 t fonti"i++)d{*ufm " f (56] = list[i".flags & GF_USED)d{*ufm "ptx = 56] = list[i".h*d**;nanafm " " f (x != 0)d{*ufm " " " f (x <emin)notdfm"     min = x;*ufm " " " f (x >lmax)notdfm"     max = x;nanafm " " qsum += x;*ufm " " "n++; nfmfmpt}nafm "}nafm}def"dfif (n == 0)notdfmretutn def"dffvg = 0um / n def"dfWARNING_3tf struc(   errllih*d**s: maxu%d fvgu%d minu%d\,
 maxcefvgllmin); nnafm/hpif lthe owan 5%.vari
int nex",avera**7, *ufmmprfyr l fixepth*d***, *ufmif (207, (fvg -lmin) <efvg && 207, (max -efvg) <efvg)d{*ufm "f", (i rigi"i <s
 t fonti"i++)d{*ufm " " f (56] = list[i".flags & GF_USED)*ufm " " "56] = list[i".h*d**, " vg;defm "}nafm G  gem.is_fixepisttchste  *ufm} n}blln,
  ".voi*
 nk M. _56]f(notd asss56] =no
)"..notdGLYPHtdfm"     *g;f"fm assn_urves; nnafmg = &56] = list[56] =no]; nnanafmg->rstatdh*d**, "irstat(g->h*d**); nnafmg->of piesoriginafmg->leighne liriginafmg->poptoriginafm f (g->ttf_poptin  != 0)d{*ufm "_ursw->glpopt(56] =no,"56] = listt;defm "g->leighne lirigina*ufm " f(ISDBG(BUILDG))nafm " "dumppopts(gll optll opt)ina*ufm "* Thrtpopt(5->of pies, __ */__, __LIN__, 5->
  t;denafm G clo# popts(gt;defm "* Thrtpopt(5->of pies, __ */__, __LIN__, 5->
  t;denafm Gmprfloa iprocthe
strotdefm " f(smoo**)d{*ufm "ptffixquadr nts(gt;defm " "* Thrtpopt(5->of pies, __ */__, __LIN__, 5->
  t;denafm Gptfsplitzigzags(gt;defm " "* Thrtpopt(5->of pies, __ */__, __LIN__, 5->
  t;denafm Gptffyr l nkcise(gt;defm " "* Thrtpopt(5->of pies, __ */__, __LIN__, 5->
  t;denafm Gptfstra
 *n (gt;defm " "* Thrtpopt(5->of pies, __ */__, __LIN__, 5->
  t;defm "}nadefm "popttoias(gt; nafm Gmprpingprocthe
strpeig*",   poiasssxp", siiasegaulpa***, *ufm "* Thrtpopt(5->of pies, __ */__, __LIN__, 5->
  t;denasw=00nafm G ixflagours(gt;defm "test ixfvdir(gt;de ".not nnafm Gmpriassprocthe
strotdefm " f (smoo**)d{*ufm "ptsmoo**joiass(gt;defm " "* Thrtpopt(5->of pies, __ */__, __LIN__, 5->
  t;defm "}nadefm "n_urves = 0;defm "{*ufm "ptGENTRY *g ;defm "ptf",(g"ori5->of pies; g ; g"ori5e->
t*ufm " " "n_urves++; nfmfm}nafm " f (n_urves > 200)d{*ufm " "WARNING_3tf struc(   errl*ufm " "ive Ghe `.%s iseh> h,ongllmay display int */
ily\ ",notdfmfm "g->
  t;defm "}na "} 
# d{*ufm "mprfyr buildes *s7, *ufm "g->flags &= ~GF_FLOAT *ufm} n}blln,
  ".voi*
wandat_g
  "(voi*)"..notd assssssssssssssi, 2,cfo, ",  ,"tspa; nnafm/hpget file
  ",lex",EBUG  gen/
s , *ufm if the  = cursw->gl
  "(56] = listt;denafm/hp /eck)fyr 
  "cw****wrong t/* defaus , *ufmf", (n rigi"n <s
 t fonti"n++)d{*ufm " assssssssssssssc;defm "f", (i rigi"(c = 56] = list[n].
  "ci") != 0i"i++)d{*ufm " " f (!(isal
 (c)"||.c == '.'"||.c == '_'"||.c == '-') *ufm "pt||.i==0"&& isdigit(c))d{ timmust sibl,
r  h****a digit7, *ufm " " "WARNING_3tf struc(   errl "Ghe `.%d.%s (%s)l ",notdfmfm "  2,cisdigit(c) ?f"
  p,
r s h****a digit" :fnotdfmfm "   "iUnicbad;t/* defaus in 
  ",notdfmfm "  2
  to
#ias(56] = list[n].
  ")t;defm "pt "56] = list[n].
  " = malloc(16t;defm "pt "d struc(56] = list[n].
  "l "_b_%d.m-nt;defm "pt "WARNING_3tf struc(   errl "t/*ng*****o %s\,
 56] = list[n].
  ");defm "pt "brsek;defmfmfm}nafm "}nafm}def"dfif( ! if the  )d{*ufm "mpr /eck)fyr duplicat u
  "c, *ufm "f", (n rigi"n <s
 t fonti"n++)d{*ufm "  fo, "steltdefm "  fo, (i rigi"i <s"&& !fo, "i"i++)d{*ufm " " " f (s; cmp(56] = list[i".
  "l 56] = list[n].
  ") == 0)d{*ufm "pt " " f (("56] = list[n].
  " = malloc(16t )==0)d{*ufm "pt " "ptf struc (   errllive) mallocfrailed.%s thing%d\,
 __ */__, __LIN__t;defm "pt """""exit(255);defm "pt """}nafm " " " "d struc(56] = list[n].
  "l "_d_%d.m-nt;denafm " " " "/hpif EBUG  genUnicsii
  "c/*ei  (wGstFln qn
  vezpars**".nnnnnnnnnnn*mrecogni
  nic if the )l Free spamretutns ping6", ".nnnnnnnnnnn*m
  "c4s  "s",
,tic k n'tzuotela/*ein*",    */".nnnnnnnnnnn*/*ufm "pt " " f(s; cmp(56] = list[i".
  "l " "s",
")) {*ufm "pt " "ptWARNING_3tf struc(   errl*ufm " """"""""""Ghe `.%d.has/* cha  " 
  " as/%d:p(%s)l t/*ng*****o %s\,
*ufm " """""""""2,ci
*ufm " """""""""56] = list[i".
  "l*ufm " """""""""56] = list[n].
  ");defm "pt """}nafm " " " "fo, "ste  *ufmpt """}nafm " "}nafm "}nanafm}def"df/*l,
r  
 *
 * chanstuff , *ufmf", (i rigi"i <s0", "c1"i"i++)d{*ufm "e", ".noti]lowercdefm}def"df/*ldo ",o,1st ro, "s*
"
 * chanby.
   , *ufmif(! if the  && sou_,c12_oding ed && sou_,c12_oding ed->to 1by
  )d{*ufm "f", (n rigi"n <s
 t fonti"n++)d{*ufm "  c = **i_,c12_oding ed->to 1by
  (56] = list[n].
  "l *ufmpt """**i_,c12_odu,/UNICONV_BYNAME_BEFOREt;defm "ptif(c>=0"&& c<0", "c1"i&& e", ".notc]i== er)*ufm "pt  e", ".notc]i= n de " "}nafm}def"df/*lee"hdo ",o,"
 * chanby.gener , *ufmif(**i_,c12_oding ed)d{*ufm "f",(iultii <sMAXUNITABLES && sou_,c12_oding ed->1",t[i]i"i++)d{*ufm " "f", (n rigi"n <s0", "c1"i"n++) dfm " """**irce _ se[n]lowercdefm """**i_,c12_oding ed->1",t[i](**i_,c12_odu);defm "pt**irce _pre, "e_bu,
  ();defm "ptcelp = cursw->gl"
 (56] = list,,"
 * cha, source _ set;defm "ptif(tcelp == 0 ) dfm " """/hpif we(h"  ran 8-bit 
 * chanhe k n'tz assmon, *pieso*/*ufm "pt "brsek;defmfm}na "} 
# d{*ufm "mpr,c128...   , o c12,ce liEBUG i",".gener *
"as (, *ufm "f",(iultii <st   oc sou_,c12/(t   oc sou_,c12[0])i"i++)d{*ufm " " f(**i_,c12[i".1",t[0]i==  opt)defm " "  claginue; nfmfm "f", (n rigi"n <s0", "c1"i"n++) dfm " """**irce _ se[n]lowercdefm """**i_,c12[i".1",t[0](**i_,c12_odu);defm "pt**irce _pre, "e_bu,
  ();defm "ptcelp = cursw->gl"
 (56] = list,,"
 * cha, source _ set;defm "ptif(tcelp == 0 ) dfm " """/hpif we(h"  ran 8-bit 
 * chanhe k n'tz assmon, *pieso*/*ufm "pt "brsek;defmfm}na "}def"dfif ( if the )d{*ufm "mprget  id p43",o,old;
  ",3",oyf' paaing"UNKNOWN"canlawyc, *ufm "f", (i rigi"i <s
 t fonti"i++)d{*ufm " "56] = list[i".
  "steltdefm "}nafm " f(celp == 0)d{ defm "ptrac8-bit - g vez8859/1m
  "c= DEBUG i",".256 t font */*ufm "ptf", (i rigi"i <s256; i++)d{tracure u256,qsibl0", "c1"i*/*ufm "pt "if (e", ".noti]l> 0)d{*ufm "pt " "56] = list[e", ".noti]".
  "steFmt3f", ".noti] *ufmpt """}nafm " "}nafm "}"
# d f(celp == 1)d{*ufm "ptrac "Ba ".n- g vez8859/1m
  "c= DEBUG i",".256 t font wan limit f*/*ufm "ptf", (n rigi"n <s256; n++)d{tracure u256,qsibl0", "c1"i*/*ufm "pt "i = **irce _rev_lookup(nt;defm "pt "if (i>=0"&& e", ".noti]l> 0)d{*ufm "pt " "56] = list[e", ".noti]".
  "steFmt3f", ".noti] *ufmpt """}nafm " "}nafm "}"mprfyr phs a7celpss*
"
 * chas(just g vezgenera ed 
  "c, *ufm "mprps, "c **iquem
  "c= DEBUGreste me6", t font */*ufm "f", (i rigi"i <s
 t fonti"i++)d{*ufm " " f (56] = list[i".
  "st= 0)d{*ufm " " " f (("56] = list[i".
  "stemalloc(16t )==0)d{*ufm "pt " "f struc (   errllive) mallocfrailed.%s thing%d\,
 __ */__, __LIN__t;defm "pt """exit(255);defm "pt "}nafm " " "d struc(56] = list[i de " "}nafm}def"3lm" nafm fm "  fo, (i rigi"i <s"&& !fo, "i"i++)d{*ufm " " " f (s; cmp(56] = list[i".
  "l 56] = list !fo, "i"i++)racDigi"i <s"&& !fo, "i"""""""""""""""ting  LATIN Cl'); nnafm/hpif c(56] = l<d->to 1by
  (56] = list[n].
  "l *ufmUniup(n0 ) doefm "pt "io = list[i".
  "l*ufm " """""""dfif ( iflist[n].
  ")N Cl're u256,qsibl "l "_whei = **nicsilxAltii<=mes enb=00o.m-nt;defm); nnafm/*u, f(EXT )  U WI3",woul
sa"pt "t , mg== 1)d{*ufm "ptrac esoriginaf "}"
# d fclp == 1)d{*f"dfmecDigi"i <s"i++)d{!idp p43eiet==2))fo, "{!idCl're u256,qs"""/hpi de " "}naim" nafm fm "  fo"i <s",(iultii <st   onuehe )l Free spamrelist[n].
  ");list[n].
n]] = list[i".
m " " " " " " f(ISDBGDigi"i <s"list[n].
  ")N Cl'r """"ist[afm fmfm "g ifault6] =  nic if "}"
# d f(clist[n].
  ");na "}def"df "io = list[i".
  "lt fonti"i+ *ufmpt """}nafm " "}nafm "}"
# dlimit f*/*ufm "ptf", (n ilxA_no1,q0x00f6,q0x0entn def-lx8imit al  U Ws s/s 143a f(i  -man_BIT __LIN__fm}def"3l",".2"
# dlimit f*/*u0ufm "mprp  nic if ;_LIN__fm}def"3l","12"
# dlimit f*/*u1ufm "mprp  null"ptf stru = list[i".
  "l*ufm " """""""""56] = generalist[n].
  "_urveso, uce ,*ufm """ = l )l Free spalimit f*/*ufm "ptf", (n rigi"n uce ,*ufm """ =] = listGDigi"GDigi"nafm f( !/.m-nt;defma ,q1"+piduN,cmfmii<=comp 0-ii<min(i>=0,q1"+ " "ly pinbt;defme1[ifilii<=", " 5 sibl,
r  h*t
 __w"pt**_suffgood" "lyf"dflt;Postrg =b 0,q1"+s_ secom*ufmlm"limi " 5 s "fgtt fontcomp "ptsot rid ammfmi",   wece K_UNI_
/.m-cn,q1"+ _ se[i");defm}de}bll " "px2019enf (56] = l}de}blrtcel*", _USED)*ufi,  gen/16-
/* ta_Iwarneeeee,f *,e__assn(EXTMAP)) f stf(frg != 0)d{*ufm ",f *++orSce _alloc == '-'riup(n0 ) defm= **n0](fmfmibl,
r  h,
 t down***",   PIDassn.*un5fm "pt """}ns"i look us, "c *ass+1quemuto
  _suffix = **i t font */*ufm "f", (i rigi"i <s
 t fonti"i++)d{*ufm " " f (56] = lis  "st= 0)d{*uft """}n", "=
)"..notd"g6", bu,
ass""""""""56] = clp s" =] = lis _ s&&  ".,o, "!=127're u256,qsibl. ra*
 tres[i->ofnveni*irciblcasssssssssssss lis _ s&igi"('cdefm """**iclp '['] = list[*gensz=ui&igi")'cdefm """**iclp ']'] = list[*", 
;f"",(iul; ([*gensz=ui&ig'\n", (n ig'\r'ruc(   errllf(frg != 0)d{*ufm ",f *++orSce _alloc == '-'riup(n128.UG  ( n
i
 t  seUurce _1",tt down***",   PIDt[*", st[n].
  ");douval
)"..notd; ([*gensz=u!warneeuc(   errllwarneeeSEP);f"fm f(frg != 0)d{*ufm ",f *++orSce _alloc == '-'riup(n0 ) G  Uurce _1"ptf"defm howpoiaper; g ;m " " "n_urvesurve*", st[n].
  "pti+=4;defm "} 
ef"dff", (r s sagengllmay dis5->
 if _GNU_SOURCE5->  s/s 140)dlop(txt)fix upt)txt, ",f *+ingpro
s '%>  s/s 140)dlop(txt)gprocthe
strpex upt)rigi:nti"i",f *+ingppex upt)r(frg == [-<opts>] [-lt,,"
 * ch| 0)des *] <(fr-es *> [<allo == >]nti"i",f *+ingppex upt)r}n"rnti"i",f *+ingppex upt)r(frg == [-<opts>] [-lt,,"
 * ch| 0)des *] <(fr-es *> -nti"i",f *+ingppex upt)r}n"rnti"i",f *+ingppex upt)r(frg == [-<opts>] [-lt,,"
 * ch| 0)des *] <(fr-es *> -h| t1asmn(E<pfa-es *>nti"i",f *+ingpgppex lop("g ;m " " x lop("Tnicsn_urv suppo *ufb"i m horty pindefm2 = 0scaif(tceg ;m " " x lop(" 5 s efm2 = 0sc(n0 ) difm "pbefpre,of pisponfm " "hortyoefsg ;m " " " x lop(" --f",-def"3lg ;m " " x upt)r}n-a -h->olud) dfm def"3l, evenres""""defmX_LEN-1) *ufm "p(tcelnti"i",f *+ingppex lop(" --pfbg ;m " " x upt)r}n-b -hoiaducfma if Epis"t ,.pfbdes *nti"i",f *+ingppex lop(" --debug db <sub = 0sc(g ;m " " x upt)r}n-d db <sub = 0sc( -hdebugnnnn* = 0sc(, runf(frg == 0d?u = lhelpnti"i",f *+ingppex lop(" --) *ufeg ;m " " x upt)r}n-e -hoiaducfma fully1) *uft ,.pfades *nti"i",f *+ingppex lop(" --tn de-u "f struc(   erx upt)r}n-F -htn defus);defm "f st1) *ufm "pevenrene"i = *MS1) *ufm "ptft&& !fnti"i",f *+in gppex lop(" -- "if (i> sub = 0sc(g ;m " " x upt)r}n-G sub = 0sc( -h128.rol.noti]llpt "if (i0sc, runf(frg == 0G?u = lhelpnti"i",f *+ingppex lop(" --,,"
 * ch,,"
 * cg ;m " " x upt)r}n-lt,,"
 * ch-h128
 tfm "f st1tolimit \,);,,"
 * c, runf(frg == 0l?u = ldifmnti"i",f *+ingppex lop(" --,,"
 * c-fmfmfm}ng ;m " " x upt)r}n-)des *h-h128
 tfm "f st1;defm "}nafm}) *ufm "ptfrg =b opt; nfmnti"i",f *+ingppex lop(" --,imi "<++)d>=<++] =>g ;m " " x upt)r}n-m"<++)d>=<++] =>\,);pt,"xstruc,imi "defm "pnse[n]lfm}++] =>
  ts:nti"i",f *+ingppex upt)r;f"fm h3tf "xstruchta_Ief" "_depi mf"dflt;PostSg =b 0enafrEpiafrnti"i",f *+ingppex lop(" --piasssxp", sub = 0sc(g ;m " " x upt)r}n-O sub = 0sc( -h128.rol.", 
 t piasssxp",, runf(frg == 0O?u = lhelpnti"i",f *+ingppex lop(" --IN__totelno++m " " x upt)r}n-pc == '-fus);imit \,cm "mnt-( nIN__t, runf(frg == 0p?u = ldifmnti"i",f *+ingppex lop(" --ui3a do++m " " x upt)r}n-ua d'-fus);*nicsUm "ptID,n-uaA meac(n0uto "if (i0scnti"i",f *+ingppex lop(" --
 tt;dl-0utohste   rano++m " " x upt)r}n-v  ran\,) "ptres[iallocy .Nokefupper U WIletsssss> ran/1000chtghnti"i",f *+ingppex lop(" --
 s0scntim " " x upt)r}n-V -hoinszi"frg == 
 s0sc".p43TTnti"i",f *+ingppex lop(" --warnp", .p43TTntim " " x upt)r}n-W".p43TTF,);pt 5 s "vem**irpi<mitm "pwarnp",s (0 -hdistcel)nti"i",f *+ingppex upt)rObsolete2 = 0sc(n(wist[bst[emov43a f(futi+st[eleU Ws):nti"i",f *+ingppex lop(" --ffmntim " " x upt)r}n-A -hwri tres[i.ffmdes *hy .STDOUTse)
 * "Ba es[iallo, = li-GAnti"i",f *+ingppex upt)r;f-f -hd"pt**  try .
c1"(res[i++] ="Ba es[iFn deB "pthta_, = li-Obnti"i",f *+ingppex upt)r;f-h -hdistceln0uto "if (i0sc"Ba hta_s, = li-Ohnti"i",f *+ingppex upt)r;f-H -hdistcelnhta_Ieubstitui0sc, = li-Ounti"i",f *+ingppex upt)r;f-o -hdistceln", 
 t  = 0mizai0sc, = li-Oonti"i",f *+ingppex upt)r;f-s -hdistceln", 
 t popt(5p",, = li-Osnti"i",f *+ingppex upt)r;f-t -hdistceln0uto-) "p"}nafm}1000x1000cf   a hol".'rix, = li-Omnti"i",f *+ingppex upt)r;f-w -h12 piesnoti]".
  g = 0u(n(us);d doc f (n_ggyiallo.nnn= li-OWnti"i",f *+ingppex upt)rWduN,no <allo == >,hwri treo <(fr-es *> iduN,e)  p
creplaced.nti"i",f *+ingppex upt)rT5 s _, _( ssmeac(n'us);STDOUT'.nti"i",f *+ingpgprun if x lopture u== UNICONV_BYNAMoinsz
 s0scngllmay displ)d{*ufm ",f *++or"frg == 6] = liTTF2PT1_VERretu.notdretutn c12[i"p"zfma (tcelp ==sub = 0sc( ssssUNICONV_BYNAMc12[<sub _tbl(en/16ruc_Ieubo_ U WI*tbl " f (**irce _ se[r s]"g6", bu,tblallodisbllistt;denafm/hp /ectblallodisbll=reolower(tblallodisblpttoias(gblalloenbll=reoupper(tblallodisblpttoias(*(tblallo++]p)l=reblallodfltd{*uft "survetutn genszi"i+g ifaulti++] ="Ba es[isub = 0sc( ssssUNICONV_BYNAMgensz<sub _dflt(en/)d{* *f,en/16ruc_Ieubo_ U WI*tbl " f (**irce _ se[r s]"g6", bu,tblallodisbllistt;denafm/hp /ec; i+blallodfltdefm """* upc(gblalloenbl, f6] = lis l
  "c/*ei upc(gblallodisbl, f6] = lt "survetutn genszi"i+g sagesmessages f (es[isub = 0sc( ssssUNICONV_BYNAMgensz<sub _ sagenen/)d{* *f,en/16ruc_Ieubo_ U WI*tbl " f (**irce _ se[r s]"d{*ufm f,rT5 s ower U WIsub = 0sc( distcelnfeati+sh,
f pisponfm "ntim " " x {*ufm f,rupper U WIsub = 0sc( et rid es[m. Ts[isuppo *>=0,ub = 0sc(,ntim " " x {*ufm f,r 5     ifaultiUNICd.m- nes[iaeati+shlp == 128.rol.0 )0scanf(frg"g6", bu,tblallodisbllistt;denafm/hp /ecx {*ufm f,r/ec%c/%c -h[%s] 6] = ligblallodisbl, gblalloenbl,  "c/*ei+blallodflt||.cet ridd"&& "distceld ligblallodfrg mset(sou_ = 3_budes n- n);pt 5 s "irst;defm "}nafm},ub = 0sc " "ly"pti+=4es[ial%s t "irst(f (eneafm fmfm y"pti+=4# d{*ufmssssUNruc_Ieubo_ U WI*ssUez<sub (en/16ruc_Ieubo_ U WI*tbl " "px201,ub =  " f (**irce _ se[r s]"g6", bu,tblallodisbllistt;denafm/hp /ec; i,ub = ")N tblallodisblpc(   errll*(tblallo++]p)l=rn].
  ");douval
&tblall.notd; ([*gensz=u,ub = ")N tblalloenblpc(   errll*(tblallo++]p)l=r1].
  ");douval
&tblall.notd; ([urvesurve"pti+=4# d{notdretuvetu; n "main = "";defm}dargcit fant s. I43fmp
v " f (**irce _____________i, j.notd 0me_ __________= l.notds. I444444444444es *m """4096enotdefbadddddddddddddc,re the,nme'ricsnotdefbadddddddddddddwsnotdefbadddddddddddddtn deb "poc sosibl-1smeac(n"d"pt**urce" LETTER . I44444444444*,,"
notdefbadddddddddddddocnotdefbaddddddddddddd,ubid.notds. I44444444444*cmd
 t;5->
 if _GNU_SOURCE5->  s/s 140"frg ==_gARNIt(a, b"g->d, e)  gARNIt_ efm(a, b"g->d, e)en/16ICONV16ruc_I = 0sca efmopts0x2022,q0x20{ "ffm"tnfreirigin'A' },,q0x20{ "f",-def"3l"tnfreirigin'a' },,q0x20{ "pfb"tnfreirigin'b' },,q0x20{ "debug"tn1reirigin'd' },,q0x20{ ") *uft"tnfreirigin'e' },,q0x20{ "tn de-u "f st"tnfreirigin'F' },,q0x20{ " "if (i>"tn1reirigin'G' },,q0x20{ ",,"
 * c"tn1reirigin'l' },,q0x20{ ",,"
 * c-fmf"tn1reirigin'L' },,q0x20{ ",imi "tn1reirigin'm' },,q0x20{ "piasssxp","tn1reirigin'O' },,q0x20{ "pN__t"tn1reirigin'p' },,q0x20{ "ui3"tn1reirigin'u' },,q0x20{ "
 tt;dl-0utohste "tn1reirigin'v' },,q0x20{ "
 s0sc"tnfreirigin'V' },,q0x20{ "warnp","tn1reirigin'W' },,q0x20{ iriginfreirigin0n_urvesngpro
s '%>  s/s 140"frg ==_gARNIt(a, b"g->d, e)  gARNIt(a, b"g-)gprocthe
sqsibl.tcelp ==O, 
 t Piasssxp", (ptf"(5p"k also",  O= 0mizai0sc)  = 0sc( ssss/16ICONV16ruc_Ieubo_ U WIopotblax2022,q0x20{ 'b'in0/*0uto-)et*/,
&tryb "ptn1re"
c1"(notdBa es[iFn deB "pthta_" },,q0x20{ 'h'in0/*0uto-)et*/,
&hta_s, 1re"0uto "if (i0sc"Ba hta_s" },,q0x20{ 'u'in0/*0uto-)et*/,
&eubhta_s, 1re"hta_Ieubstitui0sc techm "pt" },,q0x20{ 'o'in0/*0uto-)et*/,
& = 0mize, 1re"spact  = 0mizai0sc"Ba buildes *s" },,q0x20{ 's'in0/*0uto-)et*/,
&eopt(5, 1re"sopt(5p",- n",t[i of s", 
 ts" },,q0x20{ 't'in0/*0uto-)et*/,
&trac("c5", 1re"0uto-) "p"}nafm}es[is   a hol".'rix}1000x1000" },,q0x20{ 'w'in0/*0uto-)et*/,
&12 pies = 0uinfre"12 piesnoti]".
  g = 0u(n(us);d doc f (n_ggyiallo.n" },,q0x20{ 'v'in0/*0uto-)et*/,
&ve k uize, fre"ve k uize (trace) I_
/*it".ot" },,q>
 if USE_AUTOTRACE5-0x20{ 'z'in0/*0uto-)et*/,
&us)_0utotrace, fre"us);*nln0utotrace librarstsc"*it".ot (workmust lyn" },,qrocthesibUSE_AUTOTRACEssssss l{ frefrefrefref*ufm ii<min(i ub 87, *ufm "0ibl.tcelp ==es[iFs *hG"if (i0sc"B= 0sc( ssss/16ICONV16ruc_Ieubo_ U WIfgotblax2022,q0x20{ 'f'in0/*0uto-)et*/,
& "i_p0x001re"
"if (i> fyr buildes *s(.tOTA.pfad ub.pfbn" },,q0x20{ 'a'in0/*0uto-)et*/,
& "i_ffm001re"
"if (i> fyr  se[0xme'ricsdes *s(.ffm)" },,q0x20{ 'u'in0/*0uto-)et*/,
& "i_ufm001re"
"if (i> fyr m "f st1me'ricsdes *s(.ufm)" },,q0x20{ 'e'in0/*0uto-)et*/,
& "i_dvi) *, fre"
"if (i> fyr dvips}) *ufm "pes *s(.) *)" },,q0x20{ frefrefrefref*ufm ii<min(i ub 87, *ufm "0ta_I*
"i _, _=4# d{not """}ns12[<sub _tbl(opotbl); tn c12[i"p"zfmsub-B= 0sc(  ==-OT __LIN12[<sub _tbl(fgotbl); tn c12[i"p"zfmsub-B= 0sc(  ==-Gm "pt "io """",t[it s. mm pind 140)f (es[iexithol,q0x2* (wfm "pt**b"i = *bu,
 frgap*ufmUnfmshell8imit al  bl,
r  hdefm " "pt "iojl=rn].
  "g6", 1u,
argc;denafm/hp /ecjUSEDD\,);defmv" = +efm "pt " generacmd
 tk us, "c *j+1))} 
# d{*  _suffix = **i t font */*ufm "f", (i rigi"i <s
 t fonti"i++)d{*ufm " " f (56] = lis  "st= 0)d{*uft "tdsmd
 ta "} rn].
  "g6", 1u,
argc;denafm/hp /ecs**"atacmd
 t2!=0)vfmemset(secs**"atacmd
 t2!" ")d{*uft "td nt.h>
#ij=smd
 tamem!=0""""""dfif ( ifjrigi"\ngi"ion lissmd
 tamelp ' 'not """}nwhigi((doc="frg ==_gARNIt(argci!=0)v2!"FaoebAsthHfwVv:p:l:d:u:L:m:W:O:G:pt " " f(s efmoptsinafmg- g
dCl're u256,sw-efv(oehe )l Fre U WI'W': " " f(sz=u,rg == opt',') nfmfm "warn "vemd fv1, (nwarn "vem fv
  "c= DEBUGreuN,NN -oding idecim* warnp",  "vem sssc;b=00oposi, __L.p43TTntim " "       
p
c1".p43TTTTTTGDigi"i < "ptcelp = c U WI'F': " " f(seiet==2)l=r1].
  ");d "ptcelp = c U WI'o': " " f(se upt)rWarnp",:2 = 0scanoha, obsolete,fus);-Oose)
 * nti"i",f *+ingppeeeee = 0mizel=rn].
  ");d "ptcelp = c U WI'e': " " f(s) *uftl=r1].
  ");d "ptcelp = c U WI'b': " " f(s) *uftl=rpfb "WAl=r1].
  ");d "ptcelp = c U WI'A': " " f(se upt)rWarnp",:2 = 0scanAha, obsolete,fus);-GAse)
 * nti"i",f *+ingppeeeeeltiiffmd=r1].
  ");d "ptcelp = c U WI'a': " " f(sf",def"3l"=r1].
  ");d "ptcelp = c U WI's': " " f(se upt)rWarnp",:2 = 0scansha, obsolete,fus);-Osse)
 * nti"i",f *+ingppeeeeesopt(5l=rn].
  ");d "ptcelp = c U WI't': " " f(se upt)rWarnp",:2 = 0scantha, obsolete,fus);-Otse)
 * nti"i",f *+ingppeeeeetrac("c5"l=rn].
  ");d "ptcelp = c U WI'd': " " f(seie.h>
#opt','ame!=0""""""dfif (eeeesw-efv(opt','ame  "c= DEBUGre U WI'a': " " f(s f(sfbsoluttl=r1].
  ");d");d "ptcelp = cUGre U WI'r': " " f(s f(sre
 sel=rn].
  ");d");d "ptcelp = cUGre ifault: " " f(s f(seneropt','amelist'?') " " f(s f(sreuN,NN -oding idecim* Uource hdebugnnnn* = 0sc '%c' cim*nti"iopt','ame ].
  ");d");dx upt)rT5 sexit(25zi"idebugnnnn* = 0sc(.0 )0sca"i",f *+ingppeeeee");dx upt)r(sf - et rid fbsoluttlcofm "}ICd.sca"i",f *+ingppeeeee");dx upt)r(sr -hd"eafm re
 selbuild", 
 tsufm  0x0sc(g ;"i",f *+ingppeeeee");d
p
c1".p43TTTTTT");d "ptcelp = cUGre}].
  ");d "ptcelp = c U WI'm': " " f"c= DEBUGs. I4,ub = ].
  ");dlln  tr;ssssn = 0cefu,rg == opt',') nfc=fmfm ",ub = ,
&ve _ !=2  "c= DEBUGreuN,NN -oding idecim* Mis "c2 =*>=0,"xstruc,imi "cim*nti.p43TTTTTT")uN,NN -oding idespact(.0 00fd0m*nti.r;ssssn =  4_souqef"3] = l,of ", 
 t wed,NN -oding idespact(.0 00fd0m*nostr");amp'in: -mh=w'i>\,h=w'i,NN -oding idespact(.0 00fd0m*n*a d);amp'in: -mh "pt'i>\,h"pt'i
c1".p43TTTTTTGDigi"i < "ptcelpalloc(16t;defm "pt "d se  "c= DE  "c= igi"i <s"&& DEBUh
 sel=rn].
 *nt_ "WASg =b =u,rg ==ptcelpalloc(16t;defm "f(seneropt','amelim "mpnblpc((sreuN,NN -oding icim* Uource hdebugnnnn* = 0sc fontcomts:n','ame ].
  ")  "c= i-oding idespi"idebugnnnn* = 0sc(fontcomts:ingppeeeee");dx upt)r(sf - etfm re
 sef" "_depi mf"dflt;PostSg =b 0enafrEpiafrnti"i",f *+ingppex lop(" --piasssxTTTTTGDigi"i < "ptcelpalloc(16t;defm "pt "d se >gl"
 (56] = list"&& DEBUOs. I4,ub = ].
  ");dll*p6t;defm "e!=0p=",ub =;l*pec; i,up if the  )d{*ufm (c_Ieubo_ "p"zfm,l*pix = **i t fce _re =  nletst we(h"  ran'amelim "m*pec; euN,NN -oding idecim* Uource hdebugnnnn* = 0sc ,, runf(frg == 0O?pti+=4es[in','ame ].
  ")*ppt)r(sr -hd"eafmm* Uource hdeebugns}) *ultMARKelp == 0 , runf(frg == 0O?p=4es[inim-&p
c1"t; nf-hd"eafmm* Uource hdee h128.rol.", 
 &p
c1"t; nf-hd"eafmm* Uource hdee(Tost[eevem**easily128. O= 3TTnsc) thoufm);lp as \"uildes *s" }\").&p
c1"t; nf-hd"eaen/)d{* *f,en/1rce hdeb"p"zfmsuNN -oding icim* Uource hdebuTBa es[isub ati+sm " " x {*uoti]".
  lete,fusO 
c1"t; nf-hd"eaen/)d{* *fen/1rce hdeb"p"zfmsuNN -oding icim* Uource hdebu&p
c1"t; nf-hd"eaDigi"i < "ptcelpal<s"list[n].
  ")N>gl"
 (56] = list"&& DEBUGs. I4,ub = ].
  ");dll*p6t;defm "*tbl " "px201,ub =s == opt',')e!=0p=",ub =;l*pec; i,up if the  )d{*ufm (( tcelc_Ieubo_ "p"zfm,l*pix = **i t fce _re =  nletst we(h"  ran'amelim "m*pec; euN,NN -oding idecim* Uource hdebugnnnn* = 0sc ,, runf(frg == 0O?pti+=4es[in','ame ].
  ")*ppt)r(sr -hd"eafmm* Uource hdeebugns}) *ultMARKelp == 0runf(frg == 0G?p=4es[inim-&p
c1"t; nf-hd"eafmm* Uource hdee h12G.rol.", 
 &p
c1"t; nf-hd"eaen/)d{* *f,en/1rce hdeb"p"zfmsuNN -oding icim* Uource hdebuTBa es[isub ati+sm " " x {*uoti]".
  lete,fusG 
c1"t; nf-hd"eaen/)d{* *fen/1rce hdeb"p"zfmsuNN -oding icim* Uource hdebu&p
c1"t; nf-hd"eafmm* Uource hde "If".
  "stsub -Ot*> it
  Ba es[ia,mitm "}ns1 struc(   erm "0O?pti+=4es[in"",t[&p
c1"t; nf-hd"eafmm* Uource hde ")d{*ufs == 0runf( Ba3TT*> it
  Ba es[ia (OTA.pfad ub.pby es[isub).&p
c1"t; nf-hd"eaDigi"i < "ptcelpal<s"list[m """**(s->douval,NN -oding i """}ns12[s->douv6t;defm "pt "d se >gl"
 (56] = list"&& DEBUhWarnp",:2 = 0scantha, obsolete,fush;-Otse)
 * nti"i",fh*+ingppeeeeetrac("c5"l=rn].
 ubsticelp = c U WI'd': " " f(seie.h>HWarnp",:2 = 0scantha, obso" LE "pthtalete,fusH*",  be
 t " "    Bai d{*pim " ex lop(" --,imi "<,:2 = 0scantha, obsolete,fusH;-Otse)
 * nti"i",fu*+ingppeeeeesopt(5l=rn].
  ");Ieubsticelp = c U WI'd': " " f(seie.h>fWarnp",:2 = 0scantha, obsolete,fusf;-Otse)
 * nti"i",fb*+ingppeeeeetrac("c5"l=rn].
  "otdBacelp = c U WI'd': " " f(seie.h>wWarnp",:2 = 0scantha, obsolete,fusw;-Otse)
 * nti"i",fW*+ingppeeeeetrac("c5"l=rn].
 "12 piesnoticelp = c U WI's': " " f(se upt)u== opt',') nf);d uidN -oding idecim* Mis "c2 =*>=0,"xsac(n0uto. O= 3TT struc(   lo.n"onceT")uN,NN -oding ideDigi"i < "ptcelp = c U WI);d uidcelp   opt',') nf;d");dx0 &ioA56,qs;d");dx
 &i0(opt','ame  trUID=xEEtinf(futi+s ".noti]l>dvi)man1reilye(h"  ran'a; nnafmf",(iule  trUID=",ub =;oding idec!=0""""""dfif (eeeesw-efv(opt','ame  list[n '-') *uBUGre U WI' <s"&& !fo, "i"i++)d{*us "c2 =*>=0,"xsac(n0uto. L.p43TTnumeric20{ Aq0x2*dvi)man1rT")uN,NN -oding ide ideDigi"i < "ptcelpcelp = c U WI = c U WI'F': " " f(seiet==v== opt',')"12 pievs"ptcelatoiuBUGre fo, "i""""""""12 pievs"ptc<o, ",qsi12 pievs"ptc>x20{ N -oding idecim* warnp",  "vem ssscsssssvs"ptc'%d',  = or]l>e ].
  ")i12 pievs"pt < "ptcelpcei12 pievs"pt=06t;defm "pt "d se >gl"
 (56] =eiet==p== opt',') nfrigi"!= N -oding idecim* warnp",  "vem ssslo.n"one, runf(frg == 0p?43TTus]l>e ].
   -oding ideDigi"i < "ptcelp =  "ptcelpfce _leig*ufm == 0p?4*s7, == 0p?-nIN__t,re u "fge(h"  ran'ame);dll*p +efm chr ",ub = ,LANG_ARG_SEP -oding ide nfp000,qsum = 0cexcde l*p +etcelp = cUGre  runf_ists up  t/*ng*****o (gblallodisblGre  runf_ists urg \,)fm "pt "d se c!=0""""" runfswtab(s f(sr<sub -efv(opt','ame ist[nmrecogn runfswtab(s ves++;");d");dI' <s"&& !fo, "irigi"s u runfswtab(s celp = cUGre}].
  ");d "ptcelp== opt',') nfrigi"te me6", t font m "mpr /eck",ub = ,
?"),NN -oding icim* Uource hdebugnnnn "ptif(, runf(frg == 0p?4'%same ].
  ");d");dpt)r(sf - etfm re
2 = 0scanf(frglrunf(frgre,of sc(,ntim "tifeeeee");dx upt)r(sf - etf!=0""""" runfswtab(s f(sr<sub -efv(e6", t font */*ufm "furce hdee h== '.'"\n otdefbnti"i",in: ",mmust sibl,
r  runfswtab(s ves++;"must sibl,
r  runfswtab(s ve3_bud ?  runfswtab(s ve3_bud : "nleti"i",f *+i"must sibl,
c1"t; nf-hd"eaf!=0j""""j<MAXSUFFIX""jfv(opt','ame  l') nf runfswtab(s veti"i",[j](opt','ame  l') icim* Uource hdebu== ",m runfswtab(s veti"i",[j](uNN -oding icim* Uource hdebu&p
c1"t; nf-hd"}oding ideDigi"i < "ptcelp = ptcelp>gl"
 (56] =eiet==l== opt',') nfo, "i"i++)d{*ufm != N -oding idecim* warnp",  "vem ssslo.n"one,tfm "f stlete,fu O= 3TTus]l>e ].
   -oding ideDigi"i < "ptcelp =  "ptcelpfce _leig*ufm tfm "f st*s7, eirigin'LnIN__t,re u "fge(h"  ran'ame);dll*p +efm chr ",ub = ,LANG_ARG_SEP -oding ide nfp000,qsum = 0cexcde l*p +etcelp = cUGre ist !fo, "i"s up  t/*ng*****o (gblallodisblGre ist !fo, "i"s urg \,)fm "pt "d se c!=0""""" * chanhe k n'tz assmon, *pieso*/*ufm "pt "bropt','ame ist[nmrecogn])i"i++)d{*us++;");d");dI' <s"&& !fo, "iircu-bytre to defi &])i"i++)d{*celp = cUGre ist samp'i !fo, "i"i+d{*usamp'i_sc( ecelp = cUGre}].
  ");d "ptcelp== opt',') nfircu-bytre to defte me6", t font m "mpr /eck",ub = ,
?"),NN -oding icim* Uource hdebugnnnn "ptif(,tfm "f st'%same ].
  ");d");dpt)r(sf - etfm re
sf - et2 = 0scanf(frgtfm "f sre,of sc(,ntim "tifeeeee");dx upt)r(sf - etf!=0""""" * chanhe k n'tz assmon, *pieso*/*ufm "pt "bropt','ame eafmm* Uource hdee h1111111== '.'"\n",mmust sibl,
r ])i"i++)d{*us++;"must sibl,
r ])i"i++)d{*u3_bud ? ])i"i++)d{*u3_bud : "nleti"i",f *+i"must sibl,
c1"t; nf-hd"Digi"i < "ptcelp = ptcelp>gl"
 (56] =eiet==L== opt',') nfo, "i"i++)d{*ufm != N -oding idecim* warnp",  "vem ssslo.n"one,tfm "f stlete,fu O= 3TTus]l>e ].
   -oding ideDigi"i < "ptcelp = l,
r ])i"i++)re to defi &])i"i++), "g6;= l,
r ])i"i++)r"i"s u",ub =;oding i>gl"
 (56] =eiet==V== opt',')ay displ)d{*u < "ptcelpDigi"0);oding i>gl"
 (56] =f(seneropt','ame,en/1 < "ptcelpDigi"1);oding i>gl"
 (56] =n].
  "ptibAst-=",uindd"pt**u.
  "steFmt31].
 <min(s *s7, *"ata0]e(h"  r*"at+=",uindd"p,"
 * cha,Cd.sca"i" Cl'); nef,r/ec%c/%c -h[%s0scanf(frglli%x.m-&ps defexit-eptf"defs *nan1ICONV ].
   -oding* chanh****",  ding ide "c *bAst000,2)%d,eidu%t000,3etutns pin,en/1 < "ptce* chanh****",   PID->ofn] ="Ba es[iFn dtfm "f st=", " 5loNokefus]l>et """exit(255);defm "pt "sssssss(5);d=g * nv("LANG"),*decf(c>=0"&& c<0", "c1"i&hanhe k n'tz asook
str*tbl "  n'tz a"f s"pt "brsek;defmfm}na[nmrencogn])i"i++)d{*us++;")i++),efm "pt ])i"i++)d{*us++;)I' <s"&& !fo, ircu-bytre to defi &])i"i++)d{*celp = cUGrgo="Baof_itz a"f s< "ptcelp = l,
 = l,
l *uffades\,cm "?ofn] ali  -ma(h"  ran 8-bit 
 * chanhe k n'tz asook
str*tbl "  n'tz a"f s"pt "brsek;defmfm 8-bct 
c<& e", ALIAS
c"bropt','ame ist[])i"i++)d{*uali  [ceeesopt','ame }defmrencogn])i"i++)d{*uali  [ce")i++),efm "pt ])i"i++)d{*uali  [ce)I' <s"&& !fo, "iircu-bytre to defi &])i"i++)d{*celp = cUGre go="Baof_itz a"f s< "ptcelplp = l,
 = l,aof_itz a"f sopt','a nfo, "i"i++)d{*ufm != N -oding i ",f *++orSce _alloc == '-'Us(frgtfm "f st'%samfown***",  { 'v'i\n",m])i"i++)d{*us++;);= l,
r ])i"samp'i !fo, "i"i+d{*usamp'i_sc( ecelp = }***",   PID->ofn] ="Ba es[iFn d runf(frg == 0p?43y == 0runf(G  Uuri"i",fet """exirigi"te me6", t f);dll*p +efm  chr *"ata1e")'.');= l,
enf (56 == opt', nfp*decent(s +efm dup(puffi!= N -oding ie!=0p=s;l*p,up if "ptcelplp*p +esblpttoi*ppt)r(sr -hp +ef == opt',')e!=0""""" runfswtab(s f(sr ",qsiigi"s k)fyr 
  "cw****wreaf!=0j""""j<MAXSUFFIX""jfv(opt','ame  l nf runfswtab(s veti"i",[j]opt','ame  l}defmrecognp,m runfswtab(s veti"i",[j](' <s"&& !fo, "i"irigi"s u runfswtab(s celp = cUGre} i ",f *++orSce _alloc == '-'Avi) *+in gpp, runf(frg == 0p?4'%sa(56] = list[i".
  "lrigi"n Ghe `.%d.has/* cha i ",f *++orSce _alloc == '-'ggyialifmnti"i",f ="Bam "}nafades\gppe;lp avail pisporunf(frgr),NN -oding ide ide].
  ");d "ptcellp = c U WI = c U WIfree(s)celp = }** opt', nfrigi"te me6", t fonrigi"s u runfswtab(0 celp = cU ",f *++orSce _alloc == '-'Cafrga*+in g, runf(frg == 0p?u us(frg'%samby es[isub\n",mmust sibl,rigi"n Ghe `.%d.has/* ",f *++orSce _alloc == '-'ggyialifmnti"i",f ="Bam "}nafades\gppe;lp avail pisporunf(frgr),NN -oding}***",   PID->oopenciblcasm r>flags &= ~Grigi"n open *"ata1e") runf_ist);   PID->oGeii<sce _ seq0x20{ m r>flags(+=4# d{ struc(  rn].
  mby t[eleso", ptif()nti"i",inn].
  _3tf strudu%t0ph_re the
str);dll*p6t;defm*"ata2] +efm dup  *"ata1e -odingp +efm  chr *"ata2e")'.');= l,
cha, f(sr<sub) opt',')e!= (j->gl
 j"i&& eSUFFIX)%d,eirigi"n ti"i",[j](u"jfv(opt','ame ong tmrecognp+".ntigi"n ti"i",[j](sum = 0cexcde l*p +e'\0'");d "ptcellp].
  ");d "ptcelp==st,,"
 * cha,(ist[_flagsfm apen BITdfmemsmax "fix = **i t font */*ufm "fs0scanf(frglli%Caf# d{openc== e ].
  ");d "ptcBITdfmems < "ptce* chanh****",   PIDstrudu%ta2efrgllipi-56,qsdu%ta2ef1]genera ed ACE5-0xWINDOWS opt', nf'); nef,r/ec%c/*/*ufm "fs0scanf(frglli%cafrga*> idunti"i",frunf( Ba0scshel ].
   -oding iDigi"1);oding}TOTRACEssssxWINDOWSa(h"  ranpfa_flagsfmufm_flagsfmafm_flagsfm(i> fy_flagsfmist[_flag == opt', nf);d "ptc||i """}ns12=if (i> fyt fce _essageUTse)lo, = li-GA,q0x2(h"  ran'aafm_flag=0scshe;oding}N tblallo """}ns12=if (i>(i> fyt fce _essageU fy)lo, = li-GA,q0x2(h"  ran'a(i> fy_flag=0scshe;oding}N tblar/ec%c/*/pfa_flag=0scshe;oding}***",N tblar/eACEn5-0xWINDOWS opt',snc -h[%s]efbadddcde}def"/]efbadddcd"%s.f(0; in ta2e")=r1].
 ?a, ;d "ptc?'b' }, : "pfa") : "t1a"
c1"t"frg sssxWINDOWSa(h"  ransnc -h[%s]efbadddcde}def"/]efbadddcd"%s.t1a"; in ta2ec1"t"fACEssssxWINDOWSa(h"  ranllo ""> fys a7celpss*
"
(pfa_flagsfm apen ]efbadddcd"w+b"fix = **i t font */t */*ufm "fs0scanf(frglli%Caf# d{c.
 idu== e ].
  "/]efbaddd -oding ideDigi"i < "ptcelp a; nnafmf",(iule  ",f *++2rSce _alloc == '-'C.
 i},,q0x20{bl, gbl]efbaddd -oding i++)d{tracure /ec%c/*/pfa_flagsfmist[_flag == opt', nf (i> fy->of pies, _nc -h[%s]efbadddcde}def"/]efbadddcd"%s.u },,qin ta2ec ;7celpss*
"
(ufm_flagsfm apen ]efbadddcd"w+"fix = **i t font */t */*ufm "fs0scanf(frglli%Caf# d{c.
 idu== e ].
  "/]efbaddd -oding ideDigi"i < "ptcelp +)d{tracure /ec%c/*/ufm_flagsfmist[_flag == opt', nf (i>afy->of pies, _nc -h[%s]efbadddcde}def"/]efbadddcd"%s.a },,qin ta2ec ;7celpss*
"
(afm_flagsfm apen ]efbadddcd"w+"fix = **i t font */t */*ufm "fs0scanf(frglli%Caf# d{c.
 idu== e ].
  "/]efbaddd -oding ideDigi"i < "ptcelp +)d{tracure /ec%c/*/afm_flagsfmist[_flag == opt', nf (i>(i> fyt ff pies, _nc -h[%s]efbadddcde}def"/]efbadddcd"%s. fy,,qin ta2ec ;7celpss*
"
((i> fy_flagsfm apen ]efbadddcd"w+"fix = **i t font */t */*ufm "fs0scanf(frglli%Caf# d{c.
 idu== e ].
  "/]efbaddd -oding ideDigi"i < "ptcelp +)d{tracure /ec%c/*/(i> fy_flagsfmist[_flag ==*",   PID->n].
  mNowicsilxAltii<=me"i++)d{*pfades *nti"i",f *+ingppen].
  _3tACEn5-0xWINDOWS opt= 0)d{ dei" Clpfa_flags!fmist[_flagx",EBUG  gen/
s , *ufm ipa2e< "ptce* ternc_Ieub.
  ifp  gefp,uce _rs7, *nti".c  "g6", 1pt= p=0sci = list[o p=0scshe;o= l,
cha, ipe(p)uN,NN -oding ipafmf"(rglli%Caf# d{c.
 idu ipe>e ].
   -oding iDigi"1);oding}TOist[o p  ");a_flag ==*"pt= psfm dapen pfrg(frr");= l,
cha,= psf= **i t font */t pafmf"(rglli%Caf# d{yial ipe>e!= .
  },,qe ].
   -oding iDigi"1);oding}TOist[pfa_flagsfm dapen pf1e")x "f;= l,
cha, fa_flagsf= **i t font */t pafmf"(rglli%Caf# d{yial ipe>e!= *> i},,qe ].
   -oding iDigi"1);oding}TOist[ "c= D (e!=k((sum = 0ceeiet=-1:ont */t pafmf"(rglli%Caf# d{e!=kbrarstssempisr(frg == qe ].
   -oding iDigi"1);odingeiet=0: **nicsm ho  "steFmt3fg->le, fa_flag -oding iDigi"run*nti", ;d "pt",notdfmff(seneroce _ear"fge(h"  ran'afg->le,= p(u"fg->le,ofp -oding}***",  "fACEssssxWINDOWSa(h" ***"# dlimit fn rigi"n nlimit ();   PIDdfmfm "  2
  to
#ias(56] = # dlimit fn " " f (# dlimit );   PIDf", (n rigfn (_USED)*) cd{*  _# dlimit , de}def"(_USED));   PID->o 0sc(  ==-Gnon-0ngpeld, ",  ,"tspa;afm " "}nafm "}"mprfyr phs a7celps_USED)*g;o= l,
g;defm "}nafm G s celp = g->q0x0entn d sou_,c12g->orig_1].
  " sou_,c12g-> stru = ran 8-biou_,c12g->uc(   = *ufm " "iEtinfe = 56] = lis* Thrtrenti""fg= 0G?p
"i _, o= l,may display in);   PIDrigi"n <sm)" },,".voi*
wandat_IDrigi"n fdddddddd(&efvg)dat_It_IDoriginal_al
)"..notdr"pt'i0.0 / (cshgppe-efvg) u0scs_paf_emp,"
 * ch( ");d "ptce" f (x <emal
)"..notdr"pt.xEEtin(res[i++);d "ptc
"i _,ure /ec%c/al
)"..notdr"poriginal_al
)"..notdp,"
 * ch(i12 pievs"ptcnafm " samp'i!= N -D->ooo.n" },,ptif(,tfm "f s{*ufm "pt " "fn] ="Bad>=0"&  bl,Nokef..notdrIletssssaomts1rei"  ran'*ss> ran/100=00o.m-nt;0{ 'ufm);ae}bl}ns1(i12 pievs"pt),uaA m"  ran'*s O= imfrg140)f (a> r0o.nceT-GAnti"i",f butTnsc)"  ran'*s Ok"t , meirdnti"i" 0-ii<a},,q0"  ran'*h"  ranl,f ysz;o= l,
ysz blln,
  "", (n rigi"n uce ,*m " samp'i]].yMaxf;= l,
ch(
ysz<i12 pievs"ptct ff pies, _l
)"..notdr*= (cshgppei12 pievs"ptc/ ysz;oding}***",  
 * ch( ");d "ptefvgllmin); nnafm/hpif lthe owan 5%.vari
int nex"ra**7, *ufmmprfyr l |=ixepth*d;oding}***",N tblar/elmin); nnafm/hpif lt6] = generalist[n].
  "tf", (n rigi"n uce ,*ufm fyr l |=ixepth*d;oding}**m "pt " "0sc)  lways3l, evenrf(clist[n].
  ")); nnafm/hpif lthe owan 5%.vari7celpss*
 tmrecogni
  nic if the )l Free spamretutns ping6",ra**7, *ufmmprfyr l |=ixepth*d;odingggggloc(16t;defm "pt "d.
  "lt fonti"i+ *ufmpthe owan 5%.vari
int ne
"
 * chas(just guc(   eixepth*dtutns ping6DBG_TO__USED(fm "}nafm G s 5"l=rn].
 "1fm "}_m "f( (   errlliDBG_FROM__USED(fm "}nafm G s 5"l=rn].}***",  
 * ct  =c_fm agsfm avg) ct  =c_fm ag;   PIDstruct  =c_fm ags> 45. "{!ict  =c_fm ags< -45. ngi"ion t  =c_fm agsfm0.xEE**niconside,,q0x20{(h" ***"struubstiefvgllmin)indbluenue; nfmfm"""}nafm " "}nafm "}"mprfyr phs a7celpss*
"
 * chas(just guc(   eixepth*dtutns ping6g6DBG_TO__USED(fm "}nafm G s 5"l=rn].
  *ufm " "WAR(fm "}nafm G s 5"l=rn].
  *
  t;denasw=* chas(just gnafm G ixflagours(gt;defm "tes
  nic if the )l5"l=rn].
  *DBG_FROM__USED(fm "}nafm G s 5"l=rn].lp = l,
 = l,
 "WARg= 0stddd(h****",N tblar/elmin); ""56] = 4pt "bropt','ambboxnwhigiln,
   avg) bboxnwhh****",  ditin(res[i+ou D  " 5 noticf"/]exdistnotic 'v'ifet """exim avg) cs_]exdi_pc= D ropt','"12 piesnoti=06t;dedo"12 piesnoti(sub-B=csilxs "12 piesnoticinside  _3tf stru
 tsufm) nfmfm"""}nafm " "}nafm "}"mprfyr phs a7celpss*
"
 * chas(just guc(   eixepth*dtutns ping6g6DBG_TO__USED(fm "}nafm G s 5"l=rn].
  *
 tsufmenasR(fm "}nafm G s 5"l=rn].
  *
  t;denasw=* chas(just gnafm G ixflagours(gt;defm "tes
  nic if the )l5"l=rn].
  *DBG_FROM__USED(fm "}nafm G s 5"l=rn].lp = l,
 = OURCE5- 0 PID->n].
li%It seWARN Ba3=comptrshgppsub = 0frggppm",(g"od" somen].
li%styl;defm nti"i",f  O= 3TTnnn* = 0sc(as/]exdi-snotin].
li%=_gAR"ptft&&styl;defm nti"".nni",f " " ro,nti,q0al.n].
li%SBai '  bet(i>=0,qbe 5 s "fg   lutTyet.n].
l_3tf strufn]]exdii7celps  =gn f (n_(c1"t"fACEs,"
 * ch( "otdBaefvgllmin); smeac(sfm avg) ); sm_eac( ==*",   PID
  to
#i fa_flagcd"%%!PS-*s(.fFunf(t.x:u== bl, gbl]avg) e )l_psbl]avg) e )l_copyrufm)5"l=rn l.n(&tif5"l=rn
  to
#i fa_flagcd"%%%%C.
 i}onD id:u== ")i l.n(&tif55"l=rn
  to
#i fa_flagcd"%% C1fm "} "ptraF2PT1_VERr/Rretu.notdretutn c12[i,,rigi"n Ghe `.%d.h
  to
#i fa_flagcd"%% Args: bl, gblot """}5"l=rn
  to
#i fa_flagcd"%%%%EndC s "fgtf,r 5     ifaulti fa_flagcd"12 dicp43Tgin\n/FunfInfo 9 dicp4dup 3Tgin\n");   PIDdfmfm "  2
  to
#ias(56] = FunfN".nn%sbl, gbl]avg) e )l_psblm " ]avg_e )l_ti"i",);   P     ifaulti fa_flagcd"/"i",f *+'.'" .
  oo.n"pam, gbl]avg) e )l_"i",f *);   PID ifaulti fa_flagcd"/Notdde+'.'" .
  oo.n"pam, gbl]avg) e )l_copyrufm)5"l= PID ifaulti fa_flagcd"/FullN".nn'.'" .
  oo.n"pam, gbl]avg) e )l_ades 5     ifaulti fa_flagcd"/FamilyN".nn'.'" .
  oo.n"pam, gbl]avg) e )l_aamily5"l= PID nf);d uidN -odingnn*mreUID) opt',')eifaulti fa_flagcd"/ac(n0uto.%s"pam, gblmreUID)< "ptce* nnafmf",(iulm "UID=xE opt',')e!=0""""" avg) e )l_ades(eeeesw-efv(utns ping6g6m "UIDr*= 37ub-B=magic     
p,Postr *+ingaswe(h"  ran'amem "UIDr+=" avg) e )l_ades(ee-((doc= ran'ameailed.%s t stru,(gdifm "pt " "56]defbac= ran'ame'*s O= b 5losd{e!= tsuG  gere-ins "}c= ran'ame'*s>=0,s>=uss Okcompkice _1"CRCc= ran'ame'*h"  ran'amem "UIDr+="(m "UID>>24) ei0xFF"l=rn].lp = l,
 t**u.
  "" "  *+inifav iduUID);-Os4 ix, ix, -s4 999 999 (h"  ran'afifaulti fa_flagcd"/ac(n0uto.%lu"pam, gblm "UID%t'i0000+4'i00005"l=rn].}***",  
 * fifaulti fa_flagcd"/Weufm);'.'" .
  oo.n"pam, gbl]avg) e )l_styl;5"l= PID ifaulti fa_flagcd"/It  =cAm ags%f"pam, gbl t  =c_fm ag 5     ifaulti fa_flagcd"/isFexdiPc= D %s"pam, gbgllmin);vg) cs_]exdi_pc= D ? "trin0/: "f0sce");   PIDtinfe (res[iessageh*t
 __wunus]l>".noti] *ufmptdefba,
argc;denanti"i+ *ufmpthe owan 5%.vari
int ne
"
 * chas(just guc(   eixepth*dtutns ping6tdefba++"l=rn].}***",  
 *    ifaultiafm_flag'-'r 56]FunfM)" },,q4.1
   -oding ifaultiafm_flag'-'FunfN".nn%sbl, gbl]avg) e )l_psblm " ]avg_e )l_ti"i",);  ding ifaultiafm_flag'-'FullN".nnbl, gbl]avg) e )l_ades 5    ng ifaultiafm_flag'-'Notdde+bl, gbl]avg) e )l_copyrufm)5"l=rnng ifaultiafm_flag'-'u256,qsiScsim },,ntSIN__t
   -oding ifaultiafm_flag'-'FamilyN".nnbl, gbl]avg) e )l_aamily5"l=ding ifaultiafm_flag'-'Weufm);bl, gbl]avg) e )l_styl;5"l=ding ifaultiafm_flag'-'Vi",f *+bl, gbl]avg) e )l_"i",f *);  ding ifaultiafm_flag'-'Cpt**_suffg" " f (#defba);  ding ifaultiafm_flag'-'It  =cAm ags%.1m, gbl t  =c_fm ag 5    ding ifaultiafm_flag'-'AscfACi>=" " f (ln,
   avg) ascfACi>));  ding ifaultiafm_flag'-'DescfACi>=" " f (ln,
   avg) descfACi>));    ding ifaultiufm_flag'-'r 56]FunfM)" },,q4.1
   -oding ifaultiufm_flag'-'FunfN".nn%sbl, gbl]avg) e )l_psblm " ]avg_e )l_ti"i",);  ding ifaultiufm_flag'-'FullN".nnbl, gbl]avg) e )l_ades 5    ng ifaultiufm_flag'-'Notdde+bl, gbl]avg) e )l_copyrufm)5"l=rnng ifaultiufm_flag'-'u256,qsiScsim },,ntSIN__t
   -oding ifaultiufm_flag'-'FamilyN".nnbl, gbl]avg) e )l_aamily5"l=ding ifaultiufm_flag'-'Weufm);bl, gbl]avg) e )l_styl;5"l=ding ifaultiufm_flag'-'Vi",f *+bl, gbl]avg) e )l_"i",f *);  ding ifaultiufm_flag'-'Cpt**_suffg" " f (#defba);  ding ifaultiufm_flag'-'It  =cAm ags%.1m, gbl t  =c_fm ag 5    ding ifaultiufm_flag'-'AscfACi>=" " f (ln,
   avg) ascfACi>));  ding ifaultiufm_flag'-'DescfACi>=" " f (ln,
   avg) descfACi>));    dififaulti fa_flagcd"/acCi>"""}Pm " " *+bd"pam, gbgllminln,
   avg) ucCi>"""}_pm " " *));    dififaulti fa_flagcd"/acCi>"""}Thickn== q%hd"pam, e
 ts"  oo.n"pam, gbgllminln,
   avg) ucCi>"""}_thickn== ));    dififaultiafm_flag'-'acCi>"""}Thickn== q%d, gbgllminln,
   avg) ucCi>"""}_thickn== ));    dififaultiafm_flag'-'acCi>"""}Pm " " *+bd, gbgllminln,
   avg) ucCi>"""}_pm " " *));    ding ifaultiafm_flag'-'IsFexdiPc= D %s, gbgllmin);vg) cs_]exdi_pc= D ? "trin0/: "f0sce");  ding ifaultiafm_flag'-'FunfBBox+bd"bd"bd"bd, gbgllminbboxnrg(fbboxn1g(fbboxn2g(fbboxn3]);    dififaultiufm_flag'-'acCi>"""}Thickn== q%d, gbgllminln,
   avg) ucCi>"""}_thickn== ));    dififaultiufm_flag'-'acCi>"""}Pm " " *+bd, gbgllminln,
   avg) ucCi>"""}_pm " " *));    ding ifaultiufm_flag'-'IsFexdiPc= D %s, gbgllmin);vg) cs_]exdi_pc= D ? "trin0/: "f0sce");  ding ifaultiufm_flag'-'FunfBBox+bd"bd"bd"bd, gbgllminbboxnrg(fbboxn1g(fbboxn2g(fbboxn3]);    dififaulti fa_flagcd"/FunfN".nn/%sbl"pam, gbl]avg) e )l_psblm " ]avg_e )l_ti"i",);  dififaulti fa_flagcd"/PaaulTts:n0"pam, /StrokeWnotic0"pam, ");  ditinI'm4# d{ "i",ed.%s septf"d]exdis",  ,"tifaulti fa_flagcd"/FunfTts:n1"pam, ");  3tf strufn);d "ptt font */*ufm "fs fa_flagcd"/FunfM},,q0x[0.001c0"0 0.001c0"0]"pam, ");  di,N tblar/elmin)ufm "fs fa_flagcd"/FunfM},,q0x[%9.7fc0"0 %9.7fc0"0]"pam, gbgllminIDoriginal_al
)"..notdr/pt'i0.0,Doriginal_al
)"..notdr/pt'i0.0h****",   PID)ufm "fs fa_flagcd"/FunfBBox+{bd"bd"bd"bd}ts"  oo.n"pam, gbgllminbboxnrg(fbboxn1g(fbboxn2g(fbboxn3]);    dififaulti fa_flagcd"/u256,qsim "}ptfray, ");  ditin*+inm "0      
p _1"ele "fgtdenanm)" },,qhG"if  *ufmptm)" },,q=t """gllmienanti"i+ *ufmpthe owan 5%.vari
int ne
(,ra**7, *ufmmprfyr l eixepth*d7celps= l )l Fr *ufmmprq0x0entn  " sct ff pies, tm)" },,++"l=rn].}***",     ifaultiafm_flag'-'r 56]Cpt*M)" },,q" " f (#m)" },,);  dififaultiufm_flag'-'r 56]Cpt*M)" },,q" " f (#m)" },,);    dififaulti(i> fy_flagcd"/%sblu256,qsim[, gbgllmin);vg) e )l_psblm " ]avg_e )l_ti"i",);   Plmienanti"i+ *ufmpt """}nafm { " "}nafm "}"
# dlimit f*/*ufm "ptfifaulti fa_flagcf pies, "dup bd"/%sl, f" f (l,tf", (n rigi"n uce ,*ufm """ f;= l,
ch(
f", (n rigi"n uce ,*ufm fyr l eixepth*d)ub = ].
  "en/)df", (nddddddd(afm_flag'-i, "n uce ,*ufpt)r(sr -hpn/)df", (nddddddd> fyiufm_flag'-f", (n rigi"n uce ,*ufm orig_1].
, "n uce ,*ufpt)r(sr }int ne
"
"n uce ,*ufp"  ran'afifault i(i> fy_flagcd"/icCix0x%04X" f ("n uce ,*ufpt)r(sr ure /ec%c/*/fifault i(i> fy_flagcd"/ee spam, ");  di,   PIDtinessage __wm)" },,q0nan".noti] "p(tce"i",f *+ingppe ",  ,"tsp""56] = he owan 5%.vari
int ne
(,
 * chas(just guc(   eixepth*dt7celps= l )l Fr *ufmmprq0x0entn  " sct ff pies, en/)df", (nddddddd(afm_flag'--1'-ipt)r(sr -hpn/)df", (nddddddd> fyiufm_flag'-f", (n rigiim orig_1].
, i)"l=rn].}***",    dififaulti fa_flagcd"s"  oo.n"pam, curr"fgdicp4e
 , curr"fgflagseexet
   -odififaulti fa_flagcd"dup /Pfav idu16 dicp4dup 3Tgin\n");   PIDfifaulti fa_flagcd"/RD{rce _1 curr"fgflagsex D s"  rce _1 pop}exetuteoo.n"pam, g);  dififaulti fa_flagcd"/ND{noac == qpam}exetuteoo.n"pam, g);  dififaulti fa_flagcd"/NP{noac == q, f}exetuteoo.n"pam, g);   PIDtinac(n0uto. L.p43TT " "n twiutottcefm2 =i",f "
 tPfav idudicp,q0aryfet """exi);d uidN -odingnn*mreUID) opt',')eifaulti fa_flagcd"/ac(n0uto.%s"pam, gblmreUID)< "ptce* nn= l,
 t**u.
  "" "  *+inifav iduUID);-Os4 ix, ix, -s4 999 999 (h"  ran'afifaulti fa_flagcd"/ac(n0uto.%lu"pam, gblm "UID%t'i0000+4'i00005"l=rn,  
 * ch(l-1smeac(ni0(opt',')ufm "fs fa_flagcd"/Fuq0x20{ 'f0sce"pam, g);  di tblallol-1smeac(ni1(opt',')ufm "fs fa_flagcd"/Fuq0x20{ 'trin"pam, g);   PID)ufm "fs fa_flagcd"/BlueV 0scs [ 
c1"t; enanti"i+ *ufmpthbluenpt "bropt','
  to
#i fa_flagcd"%d ",mblue= 0scs*ufpt)r(s
  to
#i fa_flagcd"]"pam, g);   PID)ufm "fs fa_flagcd"/Otft&B0scs [ 
c1"t; enanti"i+ *ufmpthptft&bpt "bropt','
  to
#i fa_flagcd"%d ",mptft&b0scs*ufpt)r(s
  to
#i fa_flagcd"]"pam, g);   PIDm "mprdhw000,qsopt',')ufm "fs fa_flagcd"/StdHW [ %d ]"pam, gblmrdhwpt)r(sm "mprdvw000,qsopt',')ufm "fs fa_flagcd"/StdVW [ %d ]"pam, gblmrdvf5"l=rn
  to
#i fa_flagcd"/StemSnapH [ 
c1"t; enanti"i+ *ufmpt12s= l "WARnaph(s f(sr pt "bropt','
  to
#i fa_flagcd"%d ",m "WARnaph(s pt)r(s
  to
#i fa_flagcd"]"pam, g);  rn
  to
#i fa_flagcd"/StemSnapV [ 
c1"t; enanti"i+ *ufmpt12s= l "WARnapv(s f(sr pt "bropt','
  to
#i fa_flagcd"%d ",m "WARnapv*ufpt)r(s
  to
#i fa_flagcd"]"pam, g);   PID)ufm "fs fa_flagcd"/MinFrol.0  {16 16}"pam, ");  ditinAre.%s sep]exdis0sc) ?s",  ,"tifaulti fa_flagcd"/passwpt**5839"pam, g);   PIDtinl
culufm "pes    
p _1"subrout;"i",(h" ***"44444=5rgc;denanti"i+ *ufmpthe owan 5%.vari
int ne
"
 * chas(just guc(   eixepth*dtutns ping644444+=s
  nic if thesg"l=rn].}***",    dififaulti fa_flagcd"/Subr,q" ptfray, ",644444);  ditin000x1000"subrout;"i",(h" dififaulti fa_flagcd"dup 0 {\n\t3 0 cd{* tft&subr pop pop setcurr"fgposagetuvetu\n\t} NP
   -odififaulti fa_flagcd"dup 1 {\n\t0 1 cd{* tft&subr tuvetu\n\t} NP
   -odififaulti fa_flagcd"dup 2 {\n\t0 2 cd{* tft&subr tuvetu\n\t} NP
   -odififaulti fa_flagcd"dup 3 {\n\ttuvetu\n\t} NP
   -odi->ooulln  rIletssss"pes techm "pt" },,q0x1].
  " r(i>=(h" dififaulti fa_flagcd"dup 4 {\n\t1 3 cd{* tft&subr pop cd{*subr tuvetu\n\t} NP
   -o
 * ch(pfa_flags!fmist[_flagx", pind 140)im",ed.%s 20{ m r>wou{ '3TT*asted*ufm "pt " "essage __w tec0O?pti+rout;"i",(h" di*"44444=5rgc;dfm"""}nafm " "}nafm "}"mprfyr phs a7celpss*
"
 * chas(just guc(   eixepth*dtutns ping6g644444+=pn/)df", (nm "p(i,644444);  di(sr }int ne,  
 *    ifaulti fa_flagcd"ND
   -o
 *    ifaulti fa_flagcd"2 icCix /Cpt*Sce _1,q" pdicp4dup 3Tgin\n" (#defba);  gc;dfm"""}nafm " "}nafm "}"mprfyr phs a7celpss*
"
 * chas(just guc(   eixepth*dtutns ping6g6pn/)df", (( (   errlli}l=rn].}***",    " dififaulti fa_flagcd"e
 , e
 , s"  oo.n", f" f -odififaulti fa_flagcd"noac == q, f
   -odififaulti fa_flagcd"dup/FunfN".nnam "ex D RNIt(ai",f pop
   -odififaulti fa_flagcd"mark curr"fgflagsg->leflag
   -odififaulti fa_flagcd"cleari)mark
   -odich(pfa_flags!fmist[_flagxgc;dfm"g->le, fa_flag -o
 *    ifaultiafm_flag'-'u2dCpt*M)" },,
   -oding ifaultiufm_flag'-'u2dCpt*M)" },,
   -oodich(afm_flags!fmist[_flagx", pind 140)im",ed.%s 20{ m r>wou{ '3TT*asted*ufm "pt " "essage __wkeb=00opdata,ed.nti""fg*ufm "pt rigi"n keb=00o".voi*
wandat_IDg6pn/)dkeb=00o"afm_flagh****",  diitiufm_flags!fmist[_flagx", pind 140)im",ed.%s 20{ m r>wou{ '3TT*asted*ufm "pt " "essage __wkeb=00opdata,ed.nti""fg*ufm "pt rigi"n keb=00o".voi*
wandat_IDg6pn/)dkeb=00o"ufm_flagh****",  
 *    ifaultiafm_flag'-'u2dFunfM)" },,
   -odich(afm_flags!fmist[_flagxgc;dfm"g->le,afm_flagh***oding ifaultiufm_flag'-'u2dFunfM)" },,
   -odich(ufm_flags!fmist[_flagxgc;dfm"g->le,ufm_flagh***odififaulti(i> fy_flagcd"]"pam, g);  rniti(i> fy_flags!fmist[_flagxgc;dfm"g->le,(i> fy_flag);   PIDdfmfm " orSce _alloc == '-'Finished*-0x20{ 's'in{c.
 idd
   -oodirigi"n g->le, -ooACEn5-0xWINDOWS opt=_gAR"i);it(&ws) >,NN -odi}"t"frg s)r(sm "md{ dei" Clpfa_flags!fmist[_flagx",EBUG  * ternc_Ieub.
  ifp  gefp,uce _rs7, *nti".c  "g6", 1ptsnc -h[%s]efbadddcde}def"/]efbadddcd"%s.f(0; in ta2e") ;d "ptc?'b' }, : "pfa" h***oding
"
(o p  " apen ]efbadddcd"w+b"fix = **i t font */t *ufm "fs0scanf(frglli%Caf# d{c.
 idu== e ].
  "/]efbaddd -oding iDigi"1);oding}e* nnafmf",(iul ",f *++2rSce _alloc == '-'C.
 i},,q0x20{bl, gbl]efbaddd -oding}g6", 1ptsnc -h[%s]efbadddcde}def"/]efbadddcd"%s.t1a"; in ta2ec1"toding
"
(i p  " apen ]efbadddcd"rb"fix = **i t font */t *ufm "fs0scanf(frglli%Caf# d{s"  u== e ].
  "/]efbaddd -oding iDigi"1);oding}e* nnafmf",(iul ",f *++2rSce _alloc == '-'C1fm "}},,q0x20{bl, gbl]efbaddd -oding}g6", 1ptrun*nti", ;d "pt"1"toding ",f *++2rSce _alloc == '-'R[eleso",0x20{bl, gbl]efbaddd -oding nfo,link ]efbaddd)uN,NN mf",(iul ",f *++orSce _alloc == '-'Uuppo *>o t[elee,0x20{bl, gbl]efbaddd -odi,  "fACEssssxWINDOWSa(h" ***""g->le,ist[_flagx-odituvetu;argc,             